package com.ordermanagement.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ordermanagement.contracts.OrderBookPojo;
import com.ordermanagement.contracts.OrderDetailsPojo;
import com.ordermanagement.contracts.OrderNotFoundException;
import com.ordermanagement.dao.BooksDao;
import com.ordermanagement.dao.OrderBookDao;
import com.ordermanagement.dao.OrderDAO;
import com.ordermanagement.entities.OrderBook;
import com.ordermanagement.entities.OrderDetails;
import com.ordermanagement.services.OrderService;

@Service
@Transactional(propagation=Propagation.REQUIRED, rollbackFor=Exception.class)
public class OrderServiceImpl implements OrderService{

	@Autowired
	OrderDAO orderDao;

	@Autowired
	BooksDao bookDao;

	@Autowired
	OrderBookDao orderBookDao;


	public synchronized OrderDetailsPojo addOrder(OrderDetailsPojo order) {
		validated(order);
		OrderDetails orderDetails = new OrderDetails(order);
		orderDetails= bookDao.save(orderDetails);
		return constructOrderDetailsPojo(orderDetails);
	}

	private OrderDetailsPojo constructOrderDetailsPojo(OrderDetails orderDetails) {
		OrderDetailsPojo detailsPojo = new OrderDetailsPojo(orderDetails.getOrderId(), orderDetails.getOrderQuantity(),
				orderDetails.getInitialOrderQuantity(), orderDetails.getEntryDate(), orderDetails.getOrderPrice(),
				orderDetails.getPriceType(), constructOrderBookPojo(orderDetails.getOrderBook()), null,orderDetails.getRemainingOrderQuantity());
		return detailsPojo;
	}

	private void validated(OrderDetailsPojo order) {
		if (null == order || order.getOrderBook() == null) {
			throw new OrderNotFoundException("No Instrument Present.");
		}
	}

	public List<OrderBookPojo> getAllOrderBook() {
		List<OrderBook> listOrderBook= orderBookDao.findAll();
		List<OrderBookPojo> list = getOrderBookPojo(listOrderBook);
		return list;
	}

	private List<OrderBookPojo> getOrderBookPojo(List<OrderBook> listOrderBook) {
		List<OrderBookPojo> list = listOrderBook.stream().map(orderBook->{
			Set<OrderDetailsPojo> orderDetailsPojo = getOrderDetailsPojo(orderBook);
			OrderBookPojo bookPojo = new OrderBookPojo(orderBook.getOrderBookId(),
					orderDetailsPojo,orderBook.getStatus(),orderBook.getInstrumentId());
			return bookPojo;
		}).collect(Collectors.toList());
		return list;
	}

	private Set<OrderDetailsPojo> getOrderDetailsPojo(OrderBook orderBook) {
		if(null!= orderBook.getOrderList()) {
			Set<OrderDetailsPojo> orderDetailsPojo = orderBook.getOrderList().stream().
					map(orderDetails -> {
						OrderDetailsPojo  detailsPojo = new OrderDetailsPojo(orderDetails.getOrderId(),
								orderDetails.getOrderQuantity(),
								orderDetails.getInitialOrderQuantity(),
								orderDetails.getEntryDate(),orderDetails.getOrderPrice(),
								orderDetails.getPriceType(),null,null,orderDetails.getRemainingOrderQuantity());
						return detailsPojo;
					}).collect(Collectors.toSet());
			return orderDetailsPojo;
		}
		return new HashSet<OrderDetailsPojo>();
	}

	public synchronized OrderBookPojo addOrderBook(OrderBookPojo order) throws ConstraintViolationException{
		if (null == order.getInstrumentId() || order.getInstrumentId().isEmpty()) {
			throw new OrderNotFoundException("Please fill all the mandatory fields.");
		}
		OrderBook orderBook = new OrderBook();
		orderBook.setInstrumentId(order.getInstrumentId());
		orderBook.setStatus(true);
		orderBook =orderBookDao.save(orderBook);
		OrderBookPojo orderBookPojo = constructOrderBookPojo(orderBook);
		return orderBookPojo;
	}

	private OrderBookPojo constructOrderBookPojo(OrderBook orderBook) {
		OrderBookPojo  orderBookPojo = new OrderBookPojo(orderBook.getOrderBookId(),
				getOrderDetailsPojo(orderBook), orderBook.getStatus(),
				orderBook.getInstrumentId());
		return orderBookPojo;
	}

	public synchronized OrderBookPojo updateOrderBook(OrderBookPojo orderBook) {
		if (null == orderBook.getInstrumentId() || orderBook.getInstrumentId().isEmpty()
				|| orderBook.getOrderBookId() <= 0) {
			throw new OrderNotFoundException("Please fill all the mandatory fields.");
		}
		OrderBook foundedById=orderBookDao.findOne(orderBook.getOrderBookId());
		foundedById.setStatus(orderBook.getStatus());
		orderBookDao.save(foundedById);
		return this.constructOrderBookPojo(foundedById);
	}
}

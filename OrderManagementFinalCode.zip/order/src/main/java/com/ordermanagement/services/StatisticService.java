package com.ordermanagement.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ordermanagement.contracts.Execute;
import com.ordermanagement.contracts.LimitBreakDown;
import com.ordermanagement.contracts.Statistic;
import com.ordermanagement.dao.OrderDetailsHelper;
import com.ordermanagement.entities.OrderDetailsForStatistic;

@Service
public interface StatisticService {
	public List<Execute> getAllExecutionsDetails();
	public List<OrderDetailsHelper> getAllOrderDetails();
	public List<Statistic> getAllExecutionsDetailsForStats() ;
	public List<LimitBreakDown> getLimitBreakDownForStats();
	public List<OrderDetailsForStatistic> getAllOrderDataForStats();


}

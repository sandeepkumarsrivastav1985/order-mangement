package com.ordermanagement.contracts;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

public class Execute {

	private Integer executionId;
	private Integer orderBookId;
	private Integer quantity;
	private Double price;
	private Integer status;
	private String instrumentId;
	private Integer currentAvailability;
	private String errorMsg;
	private Double expectedPrice;
	List<LimitBreakDown> listBreakDown;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate executedDate;
	
	public Execute() {
	}

	public Execute(Integer executionId,Integer orderBookId, Integer quantity, Double price, Integer status, LocalDate executedDate,String instrumentId,Integer currentAvailability) {
		super();
		this.executionId=executionId;
		this.orderBookId = orderBookId;
		this.quantity = quantity;
		this.price = price;
		this.status = status;
		this.executedDate = LocalDate.now();
		this.instrumentId=instrumentId;
		this.currentAvailability=currentAvailability;
	}
	
	
	public List<LimitBreakDown> getListBreakDown() {
		return listBreakDown;
	}

	public void setListBreakDown(List<LimitBreakDown> listBreakDown) {
		this.listBreakDown = listBreakDown;
	}
	
	public Integer getCurrentAvailability() {
		return currentAvailability;
	}

	public void setCurrentAvailability(Integer currentAvailability) {
		this.currentAvailability = currentAvailability;
	}
	
	public Integer getExecutionId() {
		return executionId;
	}

	public void setExecutionId(Integer executionId) {
		this.executionId = executionId;
	}


	public Integer getOrderBookId() {
		return orderBookId;
	}

	public LocalDate getExecutedDate() {
		return executedDate;
	}

	public void setExecutedDate(LocalDate executedDate) {
		this.executedDate = executedDate;
	}

	public void setOrderBookId(Integer orderBookId) {
		this.orderBookId = orderBookId;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getInstrumentId() {
		return instrumentId;
	}

	public void setInstrumentId(String instrumentId) {
		this.instrumentId = instrumentId;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public Double getExpectedPrice() {
		return expectedPrice;
	}

	public void setExpectedPrice(Double expectedPrice) {
		this.expectedPrice = expectedPrice;
	}

	@Override
	public String toString() {
		return "Execute [executionId=" + executionId + ", orderBookId=" + orderBookId + ", quantity=" + quantity
				+ ", price=" + price + ", status=" + status + ", instrumentId=" + instrumentId
				+ ", currentAvailability=" + currentAvailability + ", listBreakDown=" + listBreakDown
				+ ", executedDate=" + executedDate + "]";
	}
	
	
}

package com.ordermanagement.contracts;

public class LimitBreakDown {
	
	private Integer orderBookId;
	private Integer demand;
	private Double price;
	 
	public LimitBreakDown() {
		// TODO Auto-generated constructor stub
	}
	
	public Integer getOrderBookId() {
		return orderBookId;
	}
	public void setOrderBookId(Integer orderBookId) {
		this.orderBookId = orderBookId;
	}
	public Integer getDemand() {
		return demand;
	}
	public void setDemand(Integer demand) {
		this.demand = demand;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "LimitBreakDown [orderBookId=" + orderBookId + ", demand=" + demand + ", price=" + price +"]";
	}

	
}

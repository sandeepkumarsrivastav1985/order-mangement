define(['appConfig/application'],function(app){
	app.register.controller('statistics',function($scope,  $http){
		$scope.executedDataList=[];
		$scope.executionList=[];
		$scope.executionForBookId=[];
		$scope.totalFailedQuantity;
		$scope.maxQuantity;
		$scope.minQuantity;
		$scope.earliestExecution;
		$scope.lastExecution;
		$scope.validQuantityPerExecution;
		$scope.inValidQuantity;
		var getAllOrderDetails= function(){
			$http.get("statistics/allOrderDetailsForStat").then(function(data, status) {
				if(null!=data.data && data.data!=''){
					$scope.orderDetailsForStats=data.data;
				}else{

				}

			});
		}

		$scope.getTotalOrderForBookId=function(bookId){
			let count=0;
			if($scope.orderDetailsList){
				for(let i=0;i<$scope.orderDetailsList.length;i++){
					if($scope.orderDetailsList[i].initialOrderQuantity==bookId){
						count++;
					}
				}
			}
			return count;
		}
		
		
		$scope.getTotalExecutedQuantityForBookId=function(executionListForStats,bookId){
			let validQuantity=0;
			let inValidQuantityPerExecution=0;
			let validPerExecution=0;
			let lengthOfExecution = 0;
			let executionId=0;
			if($scope.executionListForStats){
				lengthOfExecution = $scope.executionListForStats.length;
				executionId=$scope.executionListForStats[0].executionId
				for(let i=0;i< lengthOfExecution; i++ ){
					if($scope.executionListForStats[i].orderBookId == bookId && $scope.executionListForStats[i].status ==1){
						validQuantity= validQuantity + $scope.executionListForStats[i].soldQuantity;
					}
					if($scope.executionListForStats[i].orderBookId == bookId && executionId < $scope.executionListForStats[i].executionId ){
						executionId=$scope.executionListForStats[i].executionId;
						validPerExecution=0;
						inValidQuantityPerExecution=0;
					}
					if($scope.executionListForStats[i].orderBookId == bookId && $scope.executionListForStats[i].status ==0){
						inValidQuantityPerExecution= inValidQuantityPerExecution + $scope.executionListForStats[i].remainingOrderQuantity;
					} 
					if($scope.executionListForStats[i].orderBookId == bookId && $scope.executionListForStats[i].status ==1){
						validPerExecution= validPerExecution + $scope.executionListForStats[i].remainingOrderQuantity;
				}
			}
			$scope.validQuantityPerExecution = validPerExecution;
			$scope.inValidQuantity = inValidQuantityPerExecution;
			return validQuantity;
		}
		}
		$scope.getTotalPendingQuantityForBookId=function(orderDetailsForStats,bookId){
			let count=0;
			if($scope.orderDetailsForStats){
				for(let i=0;i<$scope.orderDetailsForStats.length;i++){
					if($scope.orderDetailsForStats[i].orderBookId==bookId){
						count= $scope.orderDetailsForStats[i].orderQuantity;
						
					}
				}
			}
			
			if($scope.breakDownList){
				
				
			}
			return count;
		}
		
		
		$scope.getTotalRequestedQuantityForBookId=function(bookId){
			let count=0;
			let failCount=0
			let max = 0;
			let min = 0;
			let earliestDate;
			let lastDate;
			let executionPrice
			if($scope.executionList){
				 max = $scope.executionList[0].quantity;
				 min = $scope.executionList[0].quantity;
				 earliestDate = $scope.executionList[0].executedDate;
				 lastDate = $scope.executionList[0].executedDate;
				for(let i=0;i<$scope.executionList.length;i++){
					if($scope.executionList[i].orderBookId==bookId){
						if($scope.executionList[i].orderBookId==bookId && $scope.executionList[i].status == 0){
							failCount= failCount + $scope.executionList[i].quantity;
						    $scope.totalFailedQuantity = failCount;
						}
						if($scope.executionList[i].orderBookId==bookId && $scope.executionList[i].status == 1 && max <  $scope.executionList[i].quantity){
							max = $scope.executionList[i].quantity;
						}
						if($scope.executionList[i].orderBookId==bookId && $scope.executionList[i].status == 1 && min >  $scope.executionList[i].quantity){
							min = $scope.executionList[i].quantity;
						}
						if($scope.executionList[i].orderBookId==bookId && $scope.executionList[i].status == 1 && earliestDate >  $scope.executionList[i].executedDate){
							earliestDate = $scope.executionList[i].executedDate;
						}
						if($scope.executionList[i].orderBookId==bookId && $scope.executionList[i].status == 1 && lastDate <  $scope.executionList[i].executedDate){
							lastDate = $scope.executionList[i].executedDate;
						}
						if($scope.executionList[i].orderBookId==bookId && $scope.executionList[i].status == 1){
						    $scope.executionPrice = $scope.executionList[i].price;
							count= count + $scope.executionList[i].quantity;
						}
						
						
						
					}
				}
			}
			
			$scope.earliestExecution=earliestDate;
			$scope.lastExecution=lastDate;
			$scope.maxQuantity =max;
			$scope.minQuantity = min;
			return count;
		}
		var getAllExcutedData= function(){
			$http.get("statistics/getAllExecutionsDetails").then(function(data, status) {
				if(null!=data.data && data.data!=''){
					$scope.executionList=data.data;
					uniq($scope.executionList);
				}
			});
		}

		function uniq(executionList) {
			 let count = 0;
			
				if($scope.executionList){
					$scope.executionForBookId[count++] = $scope.executionList[0].orderBookId;
				
						let uniqueBook =$scope.executionList[0].orderBookId
						for(let j=1;j<$scope.executionList.length;j++){
							if(uniqueBook == $scope.executionList[j].orderBookId){
								
							}else{
								uniqueBook =$scope.executionList[j].orderBookId
								$scope.executionForBookId[count++] = uniqueBook;
							}
							
					}
			}
		}
		
		var getAllOrderDataForStats= function(){
			$http.get("statistics/getAllOrderDataForStats").then(function(data, status) {
				if(null!=data.data && data.data!=''){
					$scope.orderDetailsList=data.data;
				}
			});
		}

		
		var getLimitBreakDowndData= function(){
			$http.get("statistics/getLimitBreakDownForStats").then(function(data, status) {
				if(null!=data.data && data.data!=''){
					$scope.breakDownList=data.data;
				}
			});
		}


		var getAllExcutedDataForStats= function(){
			$http.get("statistics/getAllExecutionsDetailsForStats").then(function(data, status) {
				if(null!=data.data && data.data!=''){
					$scope.executionListForStats=data.data;
				}
			});
		}

		getAllOrderDetails();
		getAllExcutedData();
		getLimitBreakDowndData();
		getAllOrderDataForStats();
		getAllExcutedDataForStats();


	})	;

});


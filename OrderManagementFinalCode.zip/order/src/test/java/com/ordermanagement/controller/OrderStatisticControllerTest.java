package com.ordermanagement.controller;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ordermanagement.contracts.Execute;
import com.ordermanagement.contracts.LimitBreakDown;
import com.ordermanagement.contracts.Statistic;
import com.ordermanagement.dao.OrderDetailsHelper;
import com.ordermanagement.entities.OrderDetailsForStatistic;
import com.ordermanagement.service.impl.StatisticServiceImpl;

@RunWith(SpringRunner.class)
@WebMvcTest(value = OrderStatisticController.class, secure = false)
public class OrderStatisticControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private StatisticServiceImpl statisticService;

	ArrayList<OrderDetailsForStatistic> mockOrderDetailsForStatistic = new ArrayList<OrderDetailsForStatistic>();
	List<OrderDetailsHelper> orderDetailsForStats = new ArrayList<>();

	List<Execute> mockExecutionList = new ArrayList<>();

	List<Statistic> mockListStatistic = new ArrayList<>();

	List<LimitBreakDown> mockListLimitBreakDown = new ArrayList<>();

	String orderDetails = "[{\"orderId\":1,\"orderQuantity\":200,\"initialOrderQuantity\":null,\"orderPrice\":10}]";

	String sampleJson = "[{\"bookName\":Tata, \"demand\":400}]";
	String sampleExecuteListJson = "[{\"executionId\":1, \"orderBookId\":1,\"quantity\":20,\"price\":20.0,\"status\":1,\"executedDate\":null,\"instrumentId\":Tata,\"currentAvailability\":20}]";

	@Before
	public void setup() throws JsonProcessingException {
		OrderDetailsForStatistic orderDetailsStats = new OrderDetailsForStatistic();
		orderDetailsStats.setOrderId(1);
		orderDetailsStats.setOrderQuantity(200);
		orderDetailsStats.setOrderPrice(BigDecimal.TEN);
		mockOrderDetailsForStatistic.add(orderDetailsStats);

		OrderDetailsHelper orderDetailForStat = new OrderDetailsHelper();
		orderDetailForStat.setBookName("Tata");
		orderDetailForStat.setDemand(400);
		orderDetailsForStats.add(orderDetailForStat);
		
		Execute execute = new Execute(1, 1, 20, 20.0, 1, LocalDate.now(), "Tata", 20);
		execute.setExecutedDate(null);
		mockExecutionList.add(execute );
		
		Statistic statistic = new Statistic();
		statistic.setExecutionId(1);
		statistic.setOrderId(1);
		statistic.setOrderPrice(BigDecimal.TEN);
		statistic.setSoldQuantity(20);
		mockListStatistic.add(statistic );
		
		LimitBreakDown limitBreak = new LimitBreakDown();
		limitBreak.setDemand(10);
		limitBreak.setOrderBookId(1);
		limitBreak.setPrice(20.0);
		mockListLimitBreakDown.add(limitBreak );

	}

	@Test
	public final void testGetAllOrderDetailsForStat() throws Exception {
		Mockito.when(statisticService.getAllOrderDetails()).thenReturn(orderDetailsForStats);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/statistics/allOrderDetailsForStat")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		JSONAssert.assertEquals(sampleJson, result.getResponse().getContentAsString(), false);

	}

	@Test
	public final void testGetAllExecutionsDetails() throws Exception {
		Mockito.when(statisticService.getAllExecutionsDetails()).thenReturn(mockExecutionList);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/statistics/getAllExecutionsDetails")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		JSONAssert.assertEquals(sampleExecuteListJson, result.getResponse().getContentAsString(), false);
	}

	@Test
	public final void testGetAllExecutionsDetailsForStats() throws Exception {
		Mockito.when(statisticService.getAllExecutionsDetailsForStats()).thenReturn(mockListStatistic);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/statistics/getAllExecutionsDetailsForStats")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		String responseSampleJson = "[{\"executionId\":1, \"orderId\":1,\"soldQuantity\":20,\"orderPrice\":10}]";
		JSONAssert.assertEquals(responseSampleJson, result.getResponse().getContentAsString(), false);

	}

	@Test
	public final void testGetLimitBreakDownForStats() throws Exception {
		Mockito.when(statisticService.getLimitBreakDownForStats()).thenReturn(mockListLimitBreakDown);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/statistics/getLimitBreakDownForStats")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		String responseSampleJson = "[{\"orderBookId\":1, \"demand\":10,\"price\":20.0}]";
		JSONAssert.assertEquals(responseSampleJson, result.getResponse().getContentAsString(), false);

	}

	@Test
	public final void testGetAllOrderDataForStats() throws Exception {
		Mockito.when(statisticService.getAllOrderDataForStats()).thenReturn(mockOrderDetailsForStatistic);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/statistics/getAllOrderDataForStats")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		JSONAssert.assertEquals(orderDetails, result.getResponse().getContentAsString(), false);

	}

}

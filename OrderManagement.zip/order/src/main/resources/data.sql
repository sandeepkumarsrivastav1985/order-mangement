
insert into order_book (name,status,instrument_name) values ('Book1',true,'PEN');
insert into order_details ( entry_date,  order_book_id, order_price, order_quantity, price_type) values ( sysdate,  1, 20.00, 50, 'LIMIT RPICE');
insert into order_details ( entry_date,  order_book_id, order_price, order_quantity, price_type) values ( sysdate,  1, 20.00, 80,'LIMIT RPICE');
insert into order_details ( entry_date,  order_book_id, order_price, order_quantity, price_type) values ( sysdate,  1, 20.00, 90,'LIMIT RPICE');
insert into order_details ( entry_date,  order_book_id, order_price, order_quantity, price_type) values ( sysdate,  1, 20.00, 60,'LIMIT RPICE');
insert into order_book (name,status,instrument_name) values ('Book2',true,'PENCIL');
insert into order_details ( entry_date,  order_book_id, order_price, order_quantity, price_type) values ( sysdate,  2, 30.00, 15, 'LIMIT RPICE');
insert into order_details ( entry_date,  order_book_id, order_price, order_quantity, price_type) values ( sysdate,  2, 20.00, 82,'LIMIT RPICE');
insert into order_details ( entry_date,  order_book_id, order_price, order_quantity, price_type) values ( sysdate,  2, 50.00, 95,'LIMIT RPICE');
insert into order_details ( entry_date, order_book_id, order_price, order_quantity, price_type) values ( sysdate,  2, 30.00, 120,'LIMIT RPICE');
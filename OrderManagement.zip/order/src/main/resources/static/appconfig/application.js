var app;
define(['appConfig/route','appConfig/DependencyResolver'], function (route,dependencyResolver) {

	app=angular.module('myApp',['ngRoute','angular.filter']);


	app.config(function($routeProvider,$controllerProvider,$compileProvider,$provide,$filterProvider,$locationProvider) {

		app.register={
				controller:$controllerProvider.register,
				directive:$compileProvider.directive,
				service:$provide.service,
				factory:$provide.factory,
				filter:$filterProvider.register
		};
		/*$locationProvider.html5Mode(true);*/
		$locationProvider.hashPrefix('');
		/*$locationProvider.html5Mode({
			enabled: true,
			requireBase: false
		});*/

		for(var i in route.routes){

			$routeProvider.when(route.routes[i].url,{
				templateUrl:route.routes[i].templateUrl+route.urlArg,
				resolve:dependencyResolver(route.routes[i].dependency)
			});
		}


		$routeProvider.otherwise({
			redirectTo: route.otherwise
		});

	});

	return app;
});
define([],function (){
	return function dependencyResolver (dependencies){
		return{
		load: ['$q', '$rootScope', function ($q, $rootScope) {
			var defer = $q.defer();

			requirejs(dependencies, function () {
				defer.resolve();
				$rootScope.$apply();
			});
			return defer.promise;
		}]};

	};

});
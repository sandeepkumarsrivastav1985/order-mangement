require.config({ urlArgs: "1.0"});
requirejs(["external/angular.min"], function() {
	requirejs(["external/angular-route.min","external/bootstrap.min","external/angular-filter.min","external/angular-fusioncharts.min","external/fusioncharts","external/fusioncharts.theme.fusion"], function() {
		requirejs(["appConfig/application"], function() {
			requirejs(["js/IndexController"], function() {

				angular.bootstrap(document, ['myApp']); 
			});
		});
	});

});
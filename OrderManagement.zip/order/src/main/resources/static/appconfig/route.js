define([],function(){
	return{
		otherwise:'/orders',
		urlArg:'?cd='+new Date().getTime(),
		routes:[
			{url:'/orders',
				templateUrl:'order.html',
				dependency:['js/orderCtrl']
			},
			{url:'/orderstatistics',
				templateUrl:'orderstatistics.html',
				dependency:['js/orderstatistics']
			}

			]

	}	;



});
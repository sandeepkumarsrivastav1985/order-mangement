define([],function(){
	return{
		otherwise:'/',
		urlArg:'?cd='+new Date().getTime(),
		routes:[
			{url:'/home',
				templateUrl:'home.html',
				dependency:['js/homeCtrl','js/customDirective']
			},
			{url:'/orders',
				templateUrl:'order.html',
				dependency:['js/orderCtrl','js/customDirective']
			},
			{url:'/orderstatistics',
				templateUrl:'orderstatistics.html',
				dependency:['js/orderstatistics']
			}

			]

	}	;



});
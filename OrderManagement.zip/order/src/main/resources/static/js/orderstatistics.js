define(['appConfig/application'],function(app){
	app.register.controller('statistics',function($scope,  $http){
		$scope.executedDataList=[];
		$scope.executionList=[];
		var getAllOrderDetails= function(){
			$http.get("statistics/allOrderDetailsForStat").then(function(data, status) {
				if(null!=data.data && data.data!=''){
					$scope.orderDetailsForStats=data.data;
				}else{

				}

			});
		}

		var getAllExcutedData= function(){
			$http.get("statistics/getAllExecutionsDetails").then(function(data, status) {
				if(null!=data.data && data.data!=''){
					$scope.executionList=data.data;
				}
			});
		}
		getAllOrderDetails();
		getAllExcutedData();


	})	;

});


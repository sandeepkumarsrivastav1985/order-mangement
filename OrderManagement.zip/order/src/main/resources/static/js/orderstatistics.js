define(['appConfig/application'],function(app){
	app.register.controller('statistics',function($scope,  $http){
		$scope.executedDataList=[];
		var getAllExecutedData= function(){
			$http.get("execute/allOrderDetailsForStat").then(function(data, status) {
				if(null!=data.data && data.data!=''){
					$scope.orderDetailsForStats=data.data;
					console.log($scope.orderDetailsForStats);
				}else{
				
				}

			});
		}
		getAllExecutedData();
	})	;
});


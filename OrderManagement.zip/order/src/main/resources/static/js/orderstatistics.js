define(['appConfig/application'],function(app){
	app.register.controller('statistics',function($scope,  $http){
		$scope.executedDataList=[];
		$scope.executionList=[];
		var getAllOrderDetails= function(){
			$http.get("statistics/allOrderDetailsForStat").then(function(data, status) {
				if(null!=data.data && data.data!=''){
					$scope.orderDetailsForStats=data.data;
				}else{

				}

			});
		}

		
		var getAllExcutedData= function(){
			$http.get("statistics/getAllExecutionsDetails").then(function(data, status) {
				if(null!=data.data && data.data!=''){
					$scope.executionList=data.data;
				}
			});
		}
		
		var getAllOrderDataForStats= function(){
			$http.get("statistics/getAllOrderDataForStats").then(function(data, status) {
				if(null!=data.data && data.data!=''){
					$scope.orderDetailsList=data.data;
				}
			});
		}
		
		var getLimitBreakDowndData= function(){
			$http.get("statistics/getLimitBreakDownForStats").then(function(data, status) {
				if(null!=data.data && data.data!=''){
					$scope.breakDownList=data.data;
				}
			});
		}
		
		
		var getAllExcutedDataForStats= function(){
			$http.get("statistics/getAllExecutionsDetailsForStats").then(function(data, status) {
				if(null!=data.data && data.data!=''){
					$scope.executionListForStats=data.data;
				}
			});
		}
		
		getAllOrderDetails();
		getAllExcutedData();
		getLimitBreakDowndData();
		getAllOrderDataForStats();
		getAllExcutedDataForStats();


	})	;

});


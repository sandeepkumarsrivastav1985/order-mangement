define(['appConfig/application'],function(app){
app.controller('indexController',function(){
	
	
	
})	;
	
	
});
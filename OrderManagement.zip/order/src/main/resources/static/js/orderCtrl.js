define(
		[ 'appConfig/application' ],
		function(app) {
			app.register
					.controller(
							'orderCtrl',
							function($scope, $http, $timeout) {

								$scope.orderBookList = [];
								$scope.orderBook = undefined;
								$scope.createOrderBook = false;
								$scope.showAlert = false;

								var getAllOrderBooks = function() {
									$http
											.get("orders/allOrderBooks")
											.then(
													function(data, status) {
														if (null != data.data
																&& data.data != '') {
															$scope.orderBookList = data.data;
														} else {

														}

													});
								}
								getAllOrderBooks();
								$scope.openPopUp = function(order) {
									$scope.orderQuantity = undefined;
									$scope.orderPrice = undefined;
									$scope.createOrderBook = false;
									$scope.disablePriceField = false;
									$scope.selectedPriceType = 'Limit Price';
									$scope.priceTypes = [ 'Limit Price',
											'Market Price' ];
									$scope.currentOrder = order ? order : null;
									$scope.closeAlert();
								}

								$scope.dropboxitemselected = function(priceType) {
									$scope.selectedPriceType = priceType;
									if (priceType == 'Market Price') {
										$scope.disablePriceField = true;
										$scope.orderPrice = 0;
									} else {
										$scope.disablePriceField = false;
									}
								}

								$scope.setNewOrderBook = function() {
									$scope.createOrderBook = true;
									$scope.instrumentName = undefined;
									$scope.closeAlert();
								}
								$scope.addOrderBook = function() {
									if (!$scope.instrumentName) {
										$scope
												.showErrorMsg('Please fill all the mandatory fields.');
										return;
									}
									if ($scope.createOrderBook) {
										let orderBook = {
											instrumentId : $scope.instrumentName
										};
										$http
												.post("orders/addInstrument",
														orderBook)
												.then(
														function(data, status) {
															if (null != data.data
																	&& data.data != '') {
																$scope.currentOrder = data.data;
																$scope.createOrderBook = false;
																$('#addModal')
																		.modal(
																				'hide');
																$scope.instrumentName = undefined;
																getAllOrderBooks();
															}

														},
														function(errResponse) {
															if (errResponse.data.exception
																	.includes("DataIntegrityViolationException")) {
																$scope
																		.showErrorMsg('Instrument Already Present.');
															} else {
																$scope
																		.showErrorMsg(errResponse.data.message);
															}
														});
									}
								}
								$scope.closePopUp = function() {
									$scope.dismiss();
								};

								var validateOrderPrice = function() {
									return $scope.orderPrice == undefined
											|| $scope.orderPrice < 0
											|| ($scope.orderPrice == 0 && $scope.selectedPriceType == 'Limit Price')
								}

								$scope.addOrder = function() {
									if (!$scope.orderQuantity
											|| validateOrderPrice()
											|| !$scope.selectedPriceType) {
										$scope
												.showErrorMsg('Please fill all the mandatory fields.');
										return;
									}
									if (!$scope.createOrderBook) {
										let order = {
											orderQuantity : $scope.orderQuantity,
											orderPrice : $scope.orderPrice,
											priceType : $scope.selectedPriceType,
											orderBook : $scope.currentOrder
										};
										$http
												.post("orders/addOrder", order)
												.then(
														function(data, status) {
															if (null != data.data
																	&& data.data != '') {
																getAllOrderBooks();
																$scope.disablePriceField = false;
																$scope.orderQuantity = undefined;
																$scope.orderPrice = undefined;
																$scope.selectedPriceType = 'Limit Price';
																$scope
																		.showSuccessMsg('Record added successfully');
																$scope
																		.timeOutAlert();
															} else {
																$scope
																		.closePopUp();
															}

														},
														function(errResponse) {
															$scope
																	.showErrorMsg(errResponse.data.message);
														});
									}
								}

								$scope.showSuccessMsg = function(message) {
									$scope.showAlert = true;
									$scope.alertClass = 'alert-success';
									$scope.message = message;
								}

								$scope.showErrorMsg = function(message) {
									$scope.showAlert = true;
									$scope.alertClass = 'alert-danger';
									$scope.message = message;
								}

								$scope.timeOutAlert = function() {
									$timeout(function() {
										$scope.showAlert = false;
									}, 3000);
								}

								$scope.closeAlert = function() {
									$scope.showAlert = false;
									$scope.showAlertForExecution = false;
								}

								$scope.changeOrderBook = function(order) {
									order.status = false;
									$http
											.post(
													"orders/changeOrderBookStatus",
													order)
											.then(
													function(data, status) {
														if (null != data.data
																&& data.data != '') {
															getAllOrderBooks();
														}
													},
													function(errResponse) {
														$scope
																.showErrorMsg(errResponse.data.message);
													});
								}

								$scope.openExecutePopUp = function(order) {
									$scope.executeQuantity = undefined;
									$scope.executePrice = undefined;
									$scope.currentOrderBookId = order.orderBookId;
									$scope.closeAlert();
									$scope.executionList = [ {
										orderBookId : $scope.currentOrderBookId,
										quantity : $scope.executeQuantity,
										price : $scope.executePrice
									} ];
								}

								$scope.modifyColumn = function(operation) {
									if (operation == 1) {
										$scope.executionList
												.push({
													orderBookId : $scope.currentOrderBookId,
													quantity : $scope.executeQuantity,
													price : $scope.executePrice
												});
									} else {
										if ($scope.executionList.length != 1) {
											$scope.executionList.splice(-1);
										}
									}
								}

								$scope.executeOrder = function() {
									var validationFailed = false;
									angular
											.forEach(
													$scope.executionList,
													function(execution) {
														if (!execution.quantity
																|| !execution.price) {
															$scope
																	.showErrorMsg('Please fill all the mandatory fields.');
															validationFailed = true;
														}
													})
									if (validationFailed) {
										return;
									}
									$http({
										url : 'execute/executeOrder',
										method : "POST",
										data : $scope.executionList,
										transformResponse : [ function(data) {
											return data;
										} ]
									})
											.then(
													function(data) {
														if (null != data.data
																&& data.data != '') {
															$scope
																	.openExecutePopUp($scope.currentOrderBookId);
															var successExecutions = 0;
															let parsedData = JSON
																	.parse(data.data);
															angular
																	.forEach(
																			parsedData,
																			function(
																					execution) {
																				if (execution.status == 0) {
																					successExecutions = successExecutions + 1;
																				}
																			})
															$scope.showAlertForExecution = true;
															$scope.alertClass = 'alert-success';
															$scope.executionMessage = successExecutions
																	+ ' out of '
																	+ parsedData.length
																	+ ' executed successfully.';
															if (successExecutions == 0) {
																$scope.alertClass = 'alert-danger';
																$scope.executionMessage = 'All execution Failed.';
															}

															$(
																	'#addExecuteModal')
																	.modal(
																			'hide');
														} else {

														}
													},
													function(errResponse) {
														$scope
																.showErrorMsg(errResponse.data.message);
													});

								}
							});
		});
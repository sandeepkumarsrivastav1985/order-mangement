define(['appConfig/application'],function(app){
	app.register.controller('orderCtrl',function($scope, $http){


		$scope.orderBookList=[];
		$scope.orderBook=undefined;
		$scope.createOrderBook=false;

		var getAllOrderBooks= function(){
			$http.get("orders/allOrderBooks").then(function(data, status) {
				if(null!=data.data && data.data!=''){
					$scope.orderBookList=data.data;
				}else{
					$scope.showError=true;
					$scope.showErrorMsg="No Drivers available now. Please try after sometime.";
				}

			});
		}
		getAllOrderBooks();
		$scope.openPopUp = function(order) {
			$scope.orderQuantity=undefined;
			$scope.orderPrice=undefined;
			$scope.selectedPriceType='Limit Price';
			$scope.priceTypes = ['Limit Price', 'Market Price'];
			$scope.currentOrder=order?order:null;
		}

		$scope.dropboxitemselected = function (priceType) {
			$scope.selectedPriceType = priceType;
		}

		$scope.setNewOrderBook=function(){
			$scope.createOrderBook=true;
		}
		$scope.addOrderBook=function(){
			if($scope.orderBook){
				let orderBook={
						name:$scope.orderBook,
						instrumentId:$scope.instrumentName
				};
				$http.post("orders/createOrderBook",orderBook).then(function(data, status) {
					if(null!=data.data && data.data!=''){
						$scope.currentOrder=data.data;
						$scope.createOrderBook=false;
						$scope.addOrder();
						getAllOrderBooks();
						$scope.closePopUp();
					}else{
						alert('fail');
					}

				});
			}
		}
		$scope.closePopUp=function(){
			$scope.dismiss();
		};
		$scope.addOrder=function(){
			if(!$scope.createOrderBook){
				let order={
						orderQuantity:$scope.orderQuantity,
						orderPrice:$scope.orderPrice,
						priceType:$scope.selectedPriceType,
						orderBook:$scope.currentOrder
				};
				$http.post("orders/addOrder",order).then(function(data, status) {
					if(null!=data.data && data.data!=''){
						getAllOrderBooks();
					}else{
						$scope.closePopUp();
					}

				});
			}
		}

		$scope.changeOrderBook=function(order){
			order.status=!order.status;
			$http.post("orders/changeOrderBookStatus",order).then(function(data, status) {
				if(null!=data.data && data.data!=''){
					getAllOrderBooks();
				}else{
					$scope.showError=true;
					$scope.showErrorMsg="No Drivers available now. Please try after sometime.";
				}

			});
		}
		$scope.openExecutePopUp = function(order) {
			$scope.executeQuantity=undefined;
			$scope.executePrice=undefined;
			$scope.currentOrderBookId=order.orderBookId;
			$scope.executionList=[{orderBookId:$scope.currentOrderBookId,
				quantity:$scope.executeQuantity,
				price:$scope.executePrice
			}];
		}

		$scope.modifyColumn= function(operation){
			if(operation==1){
				$scope.executionList.push({orderBookId:$scope.currentOrderBookId,
					quantity:$scope.executeQuantity,
					price:$scope.executePrice
				});
			}else{
				if($scope.executionList.length!=1){
					$scope.executionList.splice(-1);
				}
			}
		}

		$scope.executeOrder=function(){
			$http({
				url: 'execute/executeOrder',
				method: "POST",
				data: $scope.executionList,
				transformResponse: [
					function (data) { 
						return data; 
					}]    
			}).then(function(data){
				if(null!=data.data && data.data!=''){
					$scope.openExecutePopUp($scope.currentOrderBookId);
					$('#addExecuteModal').modal('hide');
				}else{
					$scope.showError=true;
					$scope.showErrorMsg="No Drivers available now. Please try after sometime.";
				}
			});

		}
	});
});
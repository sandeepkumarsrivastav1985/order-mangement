define(['appConfig/application'],function(app){
	app.register.controller('homeCtrl',function($scope, $http){
		
		$scope.cust={custId:null,custName:'',custLongitude:null,custLatitude:null,address:null,mail:''};
		$scope.bookCabSuccess=false;
		$scope.showError=false;
		
		$scope.resetData=function(a){
			$scope.cust={};
			$scope.cust.mail='';
			if(undefined==a){
			$scope.bookCabSuccess=false;
			}
			$scope.showError=false;
			$scope.dataIsMandatory=false;
			$scope.showErrorMsg='';
		}
		
		$scope.popUpOk=function(){
			$scope.bookCabSuccess=false;
			$scope.showError=false;
		}

		$scope.bookCab=function(){
			
			if($scope.cust.custName=='' || null==$scope.cust.custLongitude 
					|| null==$scope.cust.custLatitude || ''==$scope.cust.mail){
				$scope.showError=true;
				$scope.showErrorMsg="Please enter All fields";
				return;
			} 
             
			$http.post("/BookingApp/rest/bookCab", $scope.cust).then(function(data, status) {
				if(null!=data.data && data.data!=''){
				$scope.driver=data.data;
				updateDriverData(data.data);
				$scope.bookCabSuccess=true;
				$scope.resetData(1);
				}else{
					$scope.showError=true;
					$scope.showErrorMsg="No Drivers available now. Please try after sometime.";
				}

			});
		}

		function updateDriverData(data){
			for(i in $scope.bookingDataList){
				if($scope.bookingDataList[i].driverDetails.driverId==data.driverDetails.driverId){
					$scope.bookingDataList[i].custId=data.custId;
					$scope.bookingDataList[i].custName=data.custName;
				}

			}

		}
		$scope.getDriverStatus=function(){

			$http.post("/BookingApp/rest/getBookingData").then(function(data, status) {
				$scope.bookingDataList=data.data;

			});
		}

		$scope.getDriverStatus();
	});

	app.register.filter('DriverStatus', function () {
		  return function (custName) {
		      return (null==custName || undefined==custName)?'Available':'Booked';
		  };
		});
	
});



package com.ordermanagement.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ordermanagement.contracts.Execute;
import com.ordermanagement.entities.ExecuteData;
import com.ordermanagement.entities.OrderDetails;

@Service
public interface ExecutionService {
	
	public void executeOrder(List<Execute> executeList) throws CloneNotSupportedException;
	public void updateExecutionDetailsNew(ExecuteData ed, List<OrderDetails> orderDetails, boolean isValid);
	public void updateOrderDetailsList(List<OrderDetails> orderDetails);
	public List<ExecuteData> getAllExecutedData();

}

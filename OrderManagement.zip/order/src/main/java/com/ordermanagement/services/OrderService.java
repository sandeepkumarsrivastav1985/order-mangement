package com.ordermanagement.services;

import java.util.List;

import org.hibernate.exception.ConstraintViolationException;
import org.springframework.stereotype.Service;

import com.ordermanagement.contracts.OrderBookPojo;
import com.ordermanagement.contracts.OrderDetailsPojo;

@Service
public interface OrderService {
	public OrderDetailsPojo addOrder(OrderDetailsPojo order);
	public List<OrderBookPojo> getAllOrderBook();
	public OrderBookPojo addOrderBook(OrderBookPojo order) throws ConstraintViolationException;
	public OrderBookPojo updateOrderBook(OrderBookPojo orderBook);
	

}

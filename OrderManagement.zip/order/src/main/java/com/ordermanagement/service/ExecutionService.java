package com.ordermanagement.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ordermanagement.contracts.Execute;
import com.ordermanagement.dao.ExecutionDataDAO;
import com.ordermanagement.dao.OrderBookDao;
import com.ordermanagement.dao.OrderDAO;
import com.ordermanagement.dao.OrderDetailsForStats;
import com.ordermanagement.dao.StatisticsDAO;
import com.ordermanagement.entities.ExecuteData;
import com.ordermanagement.entities.OrderBook;
import com.ordermanagement.entities.OrderDetails;
import com.ordermanagement.entities.StatisticsDetails;

@Service
@Transactional(propagation=Propagation.REQUIRED, rollbackFor=Exception.class)
public class ExecutionService {
	@Autowired
	OrderDAO orderDAO;

	@Autowired
	StatisticsDAO statisticsDAO;

	@Autowired
	ExecutionDataDAO executionDao;

	@Autowired
	OrderBookDao orderBookDao;


	public void executeOrder(List<Execute> executeList) throws CloneNotSupportedException {
		if(!executeList.isEmpty()) {
			OrderBook ob=orderBookDao.findOne(executeList.get(0).getOrderBookId());
			if(!ob.getStatus()) {
				for (Execute execute : executeList) {

					List<OrderDetails> orderDetails = this.orderDAO.getOrderDettails(execute);
					List<OrderDetails> soldOrders=new ArrayList<OrderDetails>();
					if (null != orderDetails && !orderDetails.isEmpty()) {
						int sumOfProduct = getSum(orderDetails);

						if (isValidOrder(sumOfProduct, execute)) {
							soldOrders = this.findSoldOrders(orderDetails, sumOfProduct, execute);
							this.updateOrderDetailsList(orderDetails);
							double currentAvailability=this.getSum(orderDetails);
							ExecuteData ed = saveExecutedDataEntity( ob, execute, soldOrders,
									currentAvailability,true);
							this.updateExecutionDetailsNew(ed,soldOrders);
						} else {
							double currentAvailability=this.getSum(orderDetails);
							this.saveExecutedDataEntity( ob, execute, soldOrders, currentAvailability, false);
							execute.setStatus(1);
						}
					} else {
						// execute order failed
						this.saveExecutedDataEntity( ob, execute, soldOrders, 0, false);
						execute.setStatus(1);
					}
				}
			}
		}

	}

	private ExecuteData saveExecutedDataEntity( OrderBook ob,
			Execute execute, List<OrderDetails> soldOrders, double currentAvailability, boolean success) {
		ExecuteData ed=new ExecuteData();
		ed.setCurrentAvailability(currentAvailability);
		ed.setExecutedDate(new Date());
		ed.setOrderPrice(execute.getPrice());
		ed.setOrderQuantity(execute.getQuantity());
		ed.setStatus(success);
		execute.setStatus(0);
		ed.setOrderBook(ob);
		ed=this.executionDao.save(ed);

		return ed;
	}

	public void updateExecutionDetailsNew(ExecuteData ed, List<OrderDetails> soldOrders) {
		for(OrderDetails order:soldOrders) {
			StatisticsDetails sd=new StatisticsDetails();
			sd.setSoldQuantity(order.getOrderQuantity());
			sd.setExecutionData(ed);
			sd.setOrderId(order.getOrderId());
			this.statisticsDAO.save(sd);
		}


	}

	public void updateExecutionDetails(Map<ExecuteData, List<OrderDetails>> executeOrder) {

		Set<ExecuteData> keySet=executeOrder.keySet();
		for (ExecuteData ed : keySet) {
			ExecuteData foundedById=executionDao.findOne(ed.getExecutionId());
			List<OrderDetails> orderDetailsList=executeOrder.get(ed);
			for(OrderDetails order:orderDetailsList) {
				StatisticsDetails sd=new StatisticsDetails();
				sd.setSoldQuantity(order.getOrderQuantity());
				sd.setExecutionData(foundedById);
				sd.setOrderId(order.getOrderId());
				this.statisticsDAO.save(sd);
			}
		}
	}




	public void updateOrderDetailsList( List<OrderDetails> orderDetails) {
		for (OrderDetails order : orderDetails) {
			this.orderDAO.updateOrderDetails(order);
		}
	}

	private List<OrderDetails> findSoldOrders(List<OrderDetails> orderDetails, int sumOfProduct, Execute execute)
			throws CloneNotSupportedException {
		List<OrderDetails> soldList = new ArrayList<OrderDetails>();
		int sum = 0;
		for (OrderDetails order : orderDetails) {
			int countOfProductSold = Math.round((execute.getQuantity()* order.getOrderQuantity())  /sumOfProduct );
			OrderDetails sold = ((OrderDetails) order.clone());
			sold.setOrderQuantity(countOfProductSold);
			soldList.add(sold);
			order.setOrderQuantity(order.getOrderQuantity() - countOfProductSold);
			sum = sum + countOfProductSold;
		}
		if (sum != execute.getQuantity()) {
			int diff = sum - execute.getQuantity();
			// we have sold less product than asked
			if (diff < 0) {
				// start from last & do increment
				int index = orderDetails.size();
				while (diff != 0) {
					soldList.get(index-1).setOrderQuantity(soldList.get(index-1).getOrderQuantity() + 1);
					orderDetails.get(index-1).setOrderQuantity(orderDetails.get(index-1).getOrderQuantity() - 1);
					index--;
					diff++;
				}
			} else {
				// we have sold more product than asked
				// start from starting & do decrement
				int index = 0;
				while (diff != 0) {
					soldList.get(index-1).setOrderQuantity(soldList.get(index-1).getOrderQuantity() - 1);
					orderDetails.get(index-1).setOrderQuantity(orderDetails.get(index-1).getOrderQuantity() + 1);
					index++;
					diff--;
				}
			}
		}
		return soldList;
	}

	private int getSum(List<OrderDetails> orderDetails) {
		return orderDetails.stream().mapToInt(o -> o.getOrderQuantity()).sum();
	}

	private boolean isValidOrder(int sumOfProduct, Execute execute) {
		return sumOfProduct >= execute.getQuantity();
	}

	public List<ExecuteData> getAllExecutedData() {
		return executionDao.findAll();
	}

}

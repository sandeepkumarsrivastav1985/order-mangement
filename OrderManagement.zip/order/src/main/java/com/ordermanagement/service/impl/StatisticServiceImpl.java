package com.ordermanagement.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ordermanagement.contracts.Execute;
import com.ordermanagement.contracts.LimitBreakDown;
import com.ordermanagement.contracts.Statistic;
import com.ordermanagement.dao.ExecutionDataDAO;
import com.ordermanagement.dao.OrderDAO;
import com.ordermanagement.dao.OrderDetailsForStats;
import com.ordermanagement.dao.StatisticsDAO;
import com.ordermanagement.entities.ExecuteData;
import com.ordermanagement.entities.OrderDetailsForStatistic;
import com.ordermanagement.services.StatisticService;

@Service
@Transactional(propagation=Propagation.REQUIRED, rollbackFor=Exception.class)
public class StatisticServiceImpl implements StatisticService{
	
	@Autowired
	OrderDAO orderDAO;

	@Autowired
	StatisticsDAO statisticsDAO;

	@Autowired
	ExecutionDataDAO executionDao;
	
	@Autowired
	StatisticsDAO statisticDao;

	public List<Execute> getAllExecutionsDetails(){
		List<ExecuteData> executeDatas = executionDao.findAll();
		List<Execute> listExecutedData= this.convertExecuteDataToExecuteResponse(executeDatas);
		List<Statistic> lst = getAllExecutionsDetailsForStats();
		HashMap<BigDecimal, Integer> map = new HashMap<>();
		Set<Integer> setOfExecutionId= new HashSet<>();
		for(Statistic s : lst) {
			setOfExecutionId.add(s.getExecutionId());
		}
		for(Execute e : listExecutedData) {
			map = new HashMap<>();
			int totals=0;
		for(Statistic s : lst) {
			if(e.getExecutionId() == s.getExecutionId()) {
				if(map.get(s.getOrderPrice())!=null) {
					totals = map.get(s.getOrderPrice()); 
					totals=totals+s.getRemainingOrderQuantity();
					
					map.put(s.getOrderPrice(), totals);
				}else {
					map.put(s.getOrderPrice(), s.getRemainingOrderQuantity());
				}
			}
		
		}
		
		List<LimitBreakDown> lstld = new ArrayList<LimitBreakDown>();
		Set<BigDecimal> key = map.keySet();
		for(BigDecimal k : key) {
			LimitBreakDown ld = new LimitBreakDown();
			ld.setDemand(map.get(k));
			ld.setPrice(k.doubleValue());
			lstld.add(ld);
		}
		e.setListBreakDown(lstld);
		}
		
		return listExecutedData;
	}

	private List<Execute> convertExecuteDataToExecuteResponse(List<ExecuteData> executeDatas) {
		return executeDatas.stream().map(executeData ->{
			Execute execute = new Execute(executeData.getExecutionId(),executeData.getOrderBook().getOrderBookId(), executeData.getOrderQuantity(),
					executeData.getOrderPrice(),executeData.isStatus()? 1: 0,executeData.getExecutedDate(),executeData.getOrderBook().getInstrumentId(),executeData.getCurrentAvailability());
			return execute;
		}).collect(Collectors.toList());
	}

	public List<OrderDetailsForStats> getAllOrderDetails(){
		return orderDAO.getAllOrderDetailsForStats();
	}

	public List<Statistic> getAllExecutionsDetailsForStats() {
		return orderDAO.getAllExecutionsDetailsForStats();
	}
	

	@Override
	public List<LimitBreakDown> getLimitBreakDownForStats() {
		return orderDAO.getLimitBreakDownForStats();
	}

	@Override
	public List<OrderDetailsForStatistic> getAllOrderDataForStats() {
		return orderDAO.getAllOrderDataForStats();
	}



}

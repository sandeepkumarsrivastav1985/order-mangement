package com.ordermanagement.service.impl;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ordermanagement.contracts.Execute;
import com.ordermanagement.contracts.OrderBookPojo;
import com.ordermanagement.contracts.OrderDetailsPojo;
import com.ordermanagement.contracts.Statistic;
import com.ordermanagement.dao.ExecutionDataDAO;
import com.ordermanagement.dao.OrderDAO;
import com.ordermanagement.dao.OrderDetailsForStats;
import com.ordermanagement.dao.StatisticsDAO;
import com.ordermanagement.entities.ExecuteData;
import com.ordermanagement.entities.OrderDetails;
import com.ordermanagement.entities.StatisticsDetails;
import com.ordermanagement.services.StatisticService;

@Service
@Transactional(propagation=Propagation.REQUIRED, rollbackFor=Exception.class)
public class StatisticServiceImpl implements StatisticService{
	
	@Autowired
	OrderDAO orderDAO;

	@Autowired
	StatisticsDAO statisticsDAO;

	@Autowired
	ExecutionDataDAO executionDao;
	
	@Autowired
	StatisticsDAO statisticDao;

	public List<Execute> getAllExecutionsDetails(){
		List<ExecuteData> executeDatas = executionDao.findAll();
		return this.convertExecuteDataToExecuteResponse(executeDatas);
	}

	private List<Execute> convertExecuteDataToExecuteResponse(List<ExecuteData> executeDatas) {
		return executeDatas.stream().map(executeData ->{
			Execute execute = new Execute(executeData.getExecutionId(), executeData.getOrderQuantity(),
					executeData.getOrderPrice(),executeData.isStatus()? 1: 0,executeData.getExecutedDate(),executeData.getOrderBook().getInstrumentId());
			return execute;
		}).collect(Collectors.toList());
	}

	public List<OrderDetailsForStats> getAllOrderDetails(){
		return orderDAO.getAllOrderDetailsForStats();
	}

	public List<Statistic> getAllExecutionsDetailsForStats() {
		// TODO Auto-generated method stub
		
		return this.convertExecuteStatsDataToExecuteResponse(statisticDao.findAll());
	}
	
	private List<Statistic> convertExecuteStatsDataToExecuteResponse(List<StatisticsDetails> statsDatas) {
		return statsDatas.stream().map(statsData ->{
			OrderDetails orderDetails= statsData.getOrderDetails();
			HashSet<OrderDetailsPojo> set = new HashSet<OrderDetailsPojo>();
			OrderDetailsPojo obj = new OrderDetailsPojo(orderDetails.getOrderId(), orderDetails.getOrderQuantity(), orderDetails.getInitialOrderQuantity(), LocalDate.now(), orderDetails.getOrderPrice(), "", null, null);
			set.add(obj);
			Statistic stats = new Statistic(statsData.getStatasticId(), statsData.getSoldQuantity(), statsData.getExecutionData(), new OrderDetailsPojo(orderDetails.getOrderId(),
					orderDetails.getOrderQuantity(),
					orderDetails.getInitialOrderQuantity(),
					orderDetails.getEntryDate(),orderDetails.getOrderPrice(),
					orderDetails.getPriceType(),new OrderBookPojo(orderDetails.getOrderId(), set, false, orderDetails.getOrderBook().getInstrumentId()),null), statsData.isValid());
			return stats;
		}).collect(Collectors.toList());
	}



}

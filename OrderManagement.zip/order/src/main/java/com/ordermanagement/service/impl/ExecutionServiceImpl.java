package com.ordermanagement.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ordermanagement.contracts.Execute;
import com.ordermanagement.dao.ExecutionDataDAO;
import com.ordermanagement.dao.OrderBookDao;
import com.ordermanagement.dao.OrderDAO;
import com.ordermanagement.dao.StatisticsDAO;
import com.ordermanagement.entities.ExecuteData;
import com.ordermanagement.entities.OrderBook;
import com.ordermanagement.entities.OrderDetails;
import com.ordermanagement.entities.StatisticsDetails;
import com.ordermanagement.services.ExecutionService;

@Service
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ExecutionServiceImpl implements ExecutionService{
	@Autowired
	OrderDAO orderDAO;

	@Autowired
	StatisticsDAO statisticsDAO;

	@Autowired
	ExecutionDataDAO executionDao;

	@Autowired
	OrderBookDao orderBookDao;

	@Override
	public void executeOrder(List<Execute> executeList) throws CloneNotSupportedException {
		if (!executeList.isEmpty()) {
			OrderBook ob = orderBookDao.findOne(executeList.get(0).getOrderBookId());
			if (!ob.getStatus()) {
				for (Execute execute : executeList) {

					List<OrderDetails> orderDetails = this.orderDAO.getOrderDettails(execute);
					List<OrderDetails> orderDetailsforInvalid = this.orderDAO.getOrderDettailsforInvalid(execute);
					int currentAvailabilityForInvalid = this.getSum(orderDetailsforInvalid);
					List<OrderDetails> soldOrders = new ArrayList<OrderDetails>();
					if (null != orderDetails && !orderDetails.isEmpty()) {
						int sumOfProduct = getSum(orderDetails);

						if (isValidOrder(sumOfProduct, execute)) {
							soldOrders = this.findSoldOrders(orderDetails, sumOfProduct, execute);
							this.updateOrderDetailsList(orderDetails);
							int currentAvailability = this.getSum(orderDetails);
							currentAvailability=currentAvailability+currentAvailabilityForInvalid;
							ExecuteData ed = saveExecutedDataEntity(ob, execute, soldOrders, currentAvailability, true);
							this.updateExecutionDetailsNew(ed, soldOrders,true);
							this.updateExecutionDetailsNew(ed, orderDetailsforInvalid,false);
						} else {
							int currentAvailability = this.getSum(orderDetails);
							this.saveExecutedDataEntity(ob, execute, soldOrders, currentAvailability, false);
							execute.setStatus(1);
						}
					} else {
						// execute order failed
						this.saveExecutedDataEntity(ob, execute, soldOrders, currentAvailabilityForInvalid, false);
						execute.setStatus(1);
					}
				}
			}
		}

	}

	private synchronized ExecuteData saveExecutedDataEntity(OrderBook ob, Execute execute, List<OrderDetails> soldOrders,
			int currentAvailability, boolean success) {
		ExecuteData ed = new ExecuteData();
		ed.setCurrentAvailability(currentAvailability);
		ed.setExecutedDate(LocalDate.now());
		ed.setOrderPrice(execute.getPrice());
		ed.setOrderQuantity(execute.getQuantity());
		ed.setStatus(success);
		execute.setStatus(0);
		ed.setOrderBook(ob);
		ed = this.executionDao.save(ed);

		return ed;
	}
	


	public synchronized void updateExecutionDetailsNew(ExecuteData ed, List<OrderDetails> orderDetails, boolean isValid) {
		for (OrderDetails order : orderDetails) {
			StatisticsDetails sd = new StatisticsDetails();
			
			sd.setExecutionData(ed);
			sd.setOrderDetails(order);
			sd.setValid(isValid);
			if(isValid) {
				sd.setRemainingOrderQuantity(order.getRemainingOrderQuantity());
				sd.setSoldQuantity(order.getOrderQuantity());
			}else {
				sd.setRemainingOrderQuantity(order.getOrderQuantity());
				sd.setSoldQuantity(0);
			}
			this.statisticsDAO.save(sd);
		}

	}

	public synchronized void updateExecutionDetails(Map<ExecuteData, List<OrderDetails>> executeOrder) {

		Set<ExecuteData> keySet = executeOrder.keySet();
		for (ExecuteData ed : keySet) {
			ExecuteData foundedById = executionDao.findOne(ed.getExecutionId());
			List<OrderDetails> orderDetailsList = executeOrder.get(ed);
			for (OrderDetails order : orderDetailsList) {
				StatisticsDetails sd = new StatisticsDetails();
				sd.setSoldQuantity(order.getOrderQuantity());
				sd.setExecutionData(foundedById);
				sd.setOrderDetails(order);
				this.statisticsDAO.save(sd);
			}
		}
	}

	public synchronized  void updateOrderDetailsList(List<OrderDetails> orderDetails) {
		for (OrderDetails order : orderDetails) {
			this.orderDAO.updateOrderDetails(order);
		}
	}

	private List<OrderDetails> findSoldOrders(List<OrderDetails> orderDetails, int sumOfProduct, Execute execute)
			throws CloneNotSupportedException {
		List<OrderDetails> soldList = new ArrayList<OrderDetails>();
		
		int sum = 0;
		for (OrderDetails order : orderDetails) {
			int countOfProductSold = Math.round((execute.getQuantity() * order.getOrderQuantity()) / sumOfProduct);
			OrderDetails sold = ((OrderDetails) order.clone());
			sold.setOrderQuantity(countOfProductSold);
			sold.setRemainingOrderQuantity(order.getOrderQuantity() - countOfProductSold);
			soldList.add(sold);
			order.setOrderQuantity(order.getOrderQuantity() - countOfProductSold);
			sum = sum + countOfProductSold;
		}
		if (sum != execute.getQuantity()) {
			int diff = sum - execute.getQuantity();
			// we have sold less product than asked
			if (diff < 0) {
				// start from last & do increment
				int index = orderDetails.size();
				while (diff != 0) {
					soldList.get(index - 1).setOrderQuantity(soldList.get(index - 1).getOrderQuantity() + 1);
					soldList.get(index - 1).setRemainingOrderQuantity(soldList.get(index - 1).getRemainingOrderQuantity() - 1);
					orderDetails.get(index - 1).setOrderQuantity(orderDetails.get(index - 1).getOrderQuantity() - 1);
					index--;
					diff++;
				}
			} else {
				// we have sold more product than asked
				// start from starting & do decrement
				int index = 0;
				while (diff != 0) {
					soldList.get(index - 1).setOrderQuantity(soldList.get(index - 1).getOrderQuantity() - 1);
					soldList.get(index - 1).setRemainingOrderQuantity(soldList.get(index - 1).getRemainingOrderQuantity() + 1);
					orderDetails.get(index - 1).setOrderQuantity(orderDetails.get(index - 1).getOrderQuantity() + 1);
					index++;
					diff--;
				}
			}
		}
		return soldList;
	}

	private Integer getSum(List<OrderDetails> orderDetails) {
		return orderDetails.stream().mapToInt(o -> o.getOrderQuantity()).sum();
	}

	private Boolean isValidOrder(Integer sumOfProduct, Execute execute) {
		return sumOfProduct >= execute.getQuantity();
	}

	public List<ExecuteData> getAllExecutedData() {
		return executionDao.findAll();
	}

}

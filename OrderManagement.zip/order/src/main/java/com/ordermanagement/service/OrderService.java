package com.ordermanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ordermanagement.dao.BooksDao;
import com.ordermanagement.dao.OrderBookDao;
import com.ordermanagement.dao.OrderDAO;
import com.ordermanagement.entities.OrderBook;
import com.ordermanagement.entities.OrderDetails;

@Service
public class OrderService {
	
	@Autowired
	OrderDAO orderDao;
	
	@Autowired
	BooksDao bookDao;
	
	@Autowired
	OrderBookDao orderBookDao;
	
	
	public OrderDetails addOrder(OrderDetails order) {
		validated(order);
		return bookDao.save(order);
	}

	private void validated(OrderDetails order) {
		
	}
	
	public List<OrderBook> getAllOrderBook() {
		return orderBookDao.findAll();
	}
	
	public OrderBook addOrderBook(OrderBook order) {
		return orderBookDao.save(order);
	}

	public OrderBook updateOrderBook(OrderBook orderBook) {
		OrderBook foundedById=orderBookDao.findOne(orderBook.getOrderBookId());
		foundedById.setStatus(orderBook.getStatus());
		orderBookDao.save(foundedById);
		return foundedById;
	}
}

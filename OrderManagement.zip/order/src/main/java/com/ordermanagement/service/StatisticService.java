package com.ordermanagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ordermanagement.dao.OrderDAO;
import com.ordermanagement.entities.StatisticsDetails;

@Service
public class StatisticService {
	
	@Autowired
	OrderDAO orderDao;
	
	@Transactional
	public List<StatisticsDetails> getDataForStatistic() throws CloneNotSupportedException {
		return this.orderDao.getDataForStatistic();
		
		
	}

}

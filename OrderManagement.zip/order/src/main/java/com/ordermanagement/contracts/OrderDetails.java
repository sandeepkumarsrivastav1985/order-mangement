package com.ordermanagement.contracts;

import java.math.BigDecimal;

public class OrderDetails {
	
	private int orderId;

	private int orderQuantity;

	private int initialOrderQuantity;
	
	private BigDecimal orderPrice;
	
	public OrderDetails() {
		// TODO Auto-generated constructor stub
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public int getInitialOrderQuantity() {
		return initialOrderQuantity;
	}

	public void setInitialOrderQuantity(int initialOrderQuantity) {
		this.initialOrderQuantity = initialOrderQuantity;
	}

	public BigDecimal getOrderPrice() {
		return orderPrice;
	}

	public void setOrderPrice(BigDecimal orderPrice) {
		this.orderPrice = orderPrice;
	}
	
	

}

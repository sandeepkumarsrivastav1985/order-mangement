package com.ordermanagement.contracts;

public class OrderNotFoundException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1474908158421501800L;

	public OrderNotFoundException(String exception) {
		super(exception);
	}

}

package com.ordermanagement.contracts;

public class LimitBreakDown {
	
	private int orderBookId;
	private int demand;
	private double price;
	
	public int getOrderBookId() {
		return orderBookId;
	}
	public void setOrderBookId(int orderBookId) {
		this.orderBookId = orderBookId;
	}
	public int getDemand() {
		return demand;
	}
	public void setDemand(int demand) {
		this.demand = demand;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "LimitBreakDown [orderBookId=" + orderBookId + ", demand=" + demand + ", price=" + price +"]";
	}

	
}

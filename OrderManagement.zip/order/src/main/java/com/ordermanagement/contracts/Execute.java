package com.ordermanagement.contracts;

import java.util.Date;

public class Execute {

	private int orderBookId;
	private int quantity;
	private double price;
	private int status;
	private Date executedDate;
	
	Execute(){}
	
	public Execute(int orderBookId, int quantity, double price, int status, Date executedDate) {
		super();
		this.orderBookId = orderBookId;
		this.quantity = quantity;
		this.price = price;
		this.status = status;
		this.executedDate = executedDate;
	}

	public int getOrderBookId() {
		return orderBookId;
	}
	public Date getExecutedDate() {
		return executedDate;
	}

	public void setExecutedDate(Date executedDate) {
		this.executedDate = executedDate;
	}

	public void setOrderBookId(int orderBookId) {
		this.orderBookId = orderBookId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
}

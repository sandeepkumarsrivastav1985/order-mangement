package com.ordermanagement.contracts;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

public class Execute {

	private int orderBookId;
	private int quantity;
	private double price;
	private int status;
	
	private String instrumentId;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate executedDate;

	public Execute() {
	}

	public Execute(int orderBookId, int quantity, double price, int status, LocalDate executedDate,String instrumentId) {
		super();
		this.orderBookId = orderBookId;
		this.quantity = quantity;
		this.price = price;
		this.status = status;
		this.executedDate = LocalDate.now();
		this.instrumentId=instrumentId;
	}

	public int getOrderBookId() {
		return orderBookId;
	}

	public LocalDate getExecutedDate() {
		return executedDate;
	}

	public void setExecutedDate(LocalDate executedDate) {
		this.executedDate = executedDate;
	}

	public void setOrderBookId(int orderBookId) {
		this.orderBookId = orderBookId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getInstrumentId() {
		return instrumentId;
	}

	public void setInstrumentId(String instrumentId) {
		this.instrumentId = instrumentId;
	}
}

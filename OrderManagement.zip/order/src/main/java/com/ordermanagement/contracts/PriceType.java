package com.ordermanagement.contracts;

public enum PriceType {

	MARKET_PRICE("Market Price"),
	LIMIT_PRICE("Limit Price");
	
	private final String value;
	
	PriceType(String value){
		this.value=value;
	}

	public String getValue() {
		return value;
	}
}

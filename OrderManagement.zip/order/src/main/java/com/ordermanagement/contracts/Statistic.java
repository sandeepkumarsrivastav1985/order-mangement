package com.ordermanagement.contracts;

import com.ordermanagement.entities.ExecuteData;

final public class Statistic {

	private int statasticId;

	private int soldQuantity;

	private ExecuteData executionData;

	private OrderDetailsPojo orderDetails;
	
	private boolean isValid;
	
	public Statistic() {
		// TODO Auto-generated constructor stub
	}
	public Statistic(int statasticId, int soldQuantity, ExecuteData executionData, OrderDetailsPojo orderDetails, boolean isValid) {
		super();
		this.statasticId = statasticId;
		this.soldQuantity = soldQuantity;
		this.executionData = executionData;
		this.orderDetails = orderDetails;
		this.isValid = isValid;
	}

	public int getStatasticId() {
		return statasticId;
	}

	public void setStatasticId(int statasticId) {
		this.statasticId = statasticId;
	}

	public int getSoldQuantity() {
		return soldQuantity;
	}

	public void setSoldQuantity(int soldQuantity) {
		this.soldQuantity = soldQuantity;
	}

	public ExecuteData getExecutionData() {
		return executionData;
	}

	public void setExecutionData(ExecuteData executionData) {
		this.executionData = executionData;
	}

	public OrderDetailsPojo getOrderId() {
		return orderDetails;
	}

	public void setOrderId(OrderDetailsPojo orderId) {
		this.orderDetails = orderId;
	}

	public boolean isValid() {
		return isValid;
	}

	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}

	@Override
	public String toString() {
		return "Statistic [statasticId=" + statasticId + ", soldQuantity=" + soldQuantity + ", executionData="
				+ executionData + ", orderId=" + orderDetails + ", isValid=" + isValid + "]";
	}
	
	

}

package com.ordermanagement.contracts;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

final public class Statistic {

	private Integer executionId;
	private Integer orderBookId;
	private Integer orderId;
	private Integer soldQuantity;
	private Integer availableQuantity;
	private Integer remainingOrderQuantity;
	private BigDecimal orderPrice;
	private Boolean status;
	private Integer totalDemands;
	List<LimitBreakDown> list = new ArrayList<>();
	
	
	public List<LimitBreakDown> getList() {
		return list;
	}

	public void setList(List<LimitBreakDown> list) {
		this.list = list;
	}

	public Statistic() {
		// TODO Auto-generated constructor stub
	}

	public Integer getTotalDemands() {
		return totalDemands;
	}

	public void setTotalDemands(Integer totalDemands) {
		this.totalDemands = totalDemands;
	}

	
	public Integer getOrderBookId() {
		return orderBookId;
	}

	public void setOrderBookId(Integer orderBookId) {
		this.orderBookId = orderBookId;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getSoldQuantity() {
		return soldQuantity;
	}

	public void setSoldQuantity(Integer soldQuantity) {
		this.soldQuantity = soldQuantity;
	}

	public Integer getAvailableQuantity() {
		return availableQuantity;
	}

	public void setAvailableQuantity(Integer availableQuantity) {
		this.availableQuantity = availableQuantity;
	}

	public BigDecimal getOrderPrice() {
		return orderPrice;
	}

	public void setOrderPrice(BigDecimal orderPrice) {
		this.orderPrice = orderPrice;
	}

	public Boolean isStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public Integer getExecutionId() {
		return executionId;
	}

	public void setExecutionId(Integer executionId) {
		this.executionId = executionId;
	}

	public Integer getRemainingOrderQuantity() {
		return remainingOrderQuantity;
	}

	public void setRemainingOrderQuantity(Integer remainingOrderQuantity) {
		this.remainingOrderQuantity = remainingOrderQuantity;
	}

	@Override
	public String toString() {
		return "Statistic [executionId=" + executionId + ", orderBookId=" + orderBookId + ", orderId=" + orderId
				+ ", soldQuantity=" + soldQuantity + ", availableQuantity=" + availableQuantity + ", orderPrice="
				+ orderPrice + ", status=" + status + "]";
	}

}

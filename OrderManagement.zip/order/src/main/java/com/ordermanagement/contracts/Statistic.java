package com.ordermanagement.contracts;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

final public class Statistic {

	private int executionId;
	private int orderBookId;
	private int orderId;
	private int soldQuantity;
	private int availableQuantity;
	private int remainingOrderQuantity;
	private BigDecimal orderPrice;
	private boolean status;
	private int totalDemands;
	List<LimitBreakDown> list = new ArrayList<>();
	
	
	public List<LimitBreakDown> getList() {
		return list;
	}

	public void setList(List<LimitBreakDown> list) {
		this.list = list;
	}

	public Statistic() {
		// TODO Auto-generated constructor stub
	}

	public int getTotalDemands() {
		return totalDemands;
	}

	public void setTotalDemands(int totalDemands) {
		this.totalDemands = totalDemands;
	}

	
	public int getOrderBookId() {
		return orderBookId;
	}

	public void setOrderBookId(int orderBookId) {
		this.orderBookId = orderBookId;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getSoldQuantity() {
		return soldQuantity;
	}

	public void setSoldQuantity(int soldQuantity) {
		this.soldQuantity = soldQuantity;
	}

	public int getAvailableQuantity() {
		return availableQuantity;
	}

	public void setAvailableQuantity(int availableQuantity) {
		this.availableQuantity = availableQuantity;
	}

	public BigDecimal getOrderPrice() {
		return orderPrice;
	}

	public void setOrderPrice(BigDecimal orderPrice) {
		this.orderPrice = orderPrice;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public int getExecutionId() {
		return executionId;
	}

	public void setExecutionId(int executionId) {
		this.executionId = executionId;
	}

	public int getRemainingOrderQuantity() {
		return remainingOrderQuantity;
	}

	public void setRemainingOrderQuantity(int remainingOrderQuantity) {
		this.remainingOrderQuantity = remainingOrderQuantity;
	}

	@Override
	public String toString() {
		return "Statistic [executionId=" + executionId + ", orderBookId=" + orderBookId + ", orderId=" + orderId
				+ ", soldQuantity=" + soldQuantity + ", availableQuantity=" + availableQuantity + ", orderPrice="
				+ orderPrice + ", status=" + status + "]";
	}

}

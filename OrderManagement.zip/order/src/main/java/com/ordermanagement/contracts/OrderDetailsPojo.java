package com.ordermanagement.contracts;

import java.math.BigDecimal;
import java.util.Date;

import com.ordermanagement.entities.OrderBook;

public class OrderDetailsPojo {
		
	private int orderId;
	
	private int orderQuantity;
	
	private int initialOrderQuantity;
	
	private Date entryDate;
	
	private BigDecimal orderPrice;
	
	private String priceType;
	
	private OrderBookPojo orderBookPojo;
	
	private OrderBook orderBook;
	
	public OrderDetailsPojo() {}
	

	public OrderDetailsPojo(int orderId, int orderQuantity, int initialOrderQuantity, Date entryDate,
			BigDecimal orderPrice, String priceType, OrderBookPojo orderBookPojo, OrderBook orderBook) {
		super();
		this.orderId = orderId;
		this.orderQuantity = orderQuantity;
		this.initialOrderQuantity = initialOrderQuantity;
		this.entryDate = entryDate;
		this.orderPrice = orderPrice;
		this.priceType = priceType;
		this.orderBookPojo = orderBookPojo;
		this.orderBook = orderBook;
	}


	public OrderBookPojo getOrderBookPojo() {
		return orderBookPojo;
	}


	public void setOrderBookPojo(OrderBookPojo orderBookPojo) {
		this.orderBookPojo = orderBookPojo;
	}


	public OrderBook getOrderBook() {
		return orderBook;
	}


	public void setOrderBook(OrderBook orderBook) {
		this.orderBook = orderBook;
	}


	public int getOrderId() {
		return orderId;
	}


	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}


	public int getOrderQuantity() {
		return orderQuantity;
	}


	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}


	public Date getEntryDate() {
		return entryDate;
	}


	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}


	public BigDecimal getOrderPrice() {
		return orderPrice;
	}


	public void setOrderPrice(BigDecimal orderPrice) {
		this.orderPrice = orderPrice;
	}


	public String getPriceType() {
		return priceType;
	}


	public void setPriceType(String priceType) {
		this.priceType = priceType;
	}


	public int getInitialOrderQuantity() {
		return initialOrderQuantity;
	}


	public void setInitialOrderQuantity(int initialOrderQuantity) {
		this.initialOrderQuantity = initialOrderQuantity;
	}


	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	
	@Override
	public String toString() {
		return "OrderDetails [orderId=" + orderId + ", orderQuantity=" + orderQuantity + ", entryDate=" + entryDate
				+ ", orderPrice=" + orderPrice + ", priceType=" + priceType 
				+ ", orderBook=" + orderBook + "]";
	}

	

}

package com.ordermanagement.contracts;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.ordermanagement.entities.OrderBook;

final public class OrderDetailsPojo {

	private int orderId;

	private int orderQuantity;

	private int initialOrderQuantity;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate entryDate;

	private BigDecimal orderPrice;

	private String priceType;

	private OrderBookPojo orderBookPojo;

	private OrderBook orderBook;

	@SuppressWarnings("unused")
	private OrderDetailsPojo() {
	}

	public OrderDetailsPojo(int orderId, int orderQuantity, int initialOrderQuantity, LocalDate entryDate,
			BigDecimal orderPrice, String priceType, OrderBookPojo orderBookPojo, OrderBook orderBook) {
		super();
		this.orderId = orderId;
		this.orderQuantity = orderQuantity;
		this.initialOrderQuantity = initialOrderQuantity;
		this.entryDate = entryDate;
		this.orderPrice = new BigDecimal(orderPrice.intValue());
		this.priceType = priceType;
		this.orderBookPojo = orderBookPojo;
		this.orderBook = orderBook;
	}

	public OrderBookPojo getOrderBookPojo() {
		return orderBookPojo;
	}

	public OrderBook getOrderBook() {
		return orderBook;
	}

	public int getOrderId() {
		return orderId;
	}

	public int getOrderQuantity() {
		return orderQuantity;
	}

	public LocalDate getEntryDate() {
		return entryDate;
	}

	public BigDecimal getOrderPrice() {
		return new BigDecimal(orderPrice.intValue());
	}

	public String getPriceType() {
		return priceType;
	}

	public int getInitialOrderQuantity() {
		return initialOrderQuantity;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	@Override
	public String toString() {
		return "OrderDetails [orderId=" + orderId + ", orderQuantity=" + orderQuantity + ", entryDate=" + entryDate
				+ ", orderPrice=" + orderPrice + ", priceType=" + priceType + ", orderBook=" + orderBook + "]";
	}

}

package com.ordermanagement.entities;

import java.math.BigDecimal;

public class OrderDetailsForStatistic {
	
	private Integer orderId;

	private Integer orderQuantity;

	private Integer initialOrderQuantity;
	
	private BigDecimal orderPrice;
	
	public OrderDetailsForStatistic() {
		// TODO Auto-generated constructor stub
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(Integer orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public Integer getInitialOrderQuantity() {
		return initialOrderQuantity;
	}

	public void setInitialOrderQuantity(Integer initialOrderQuantity) {
		this.initialOrderQuantity = initialOrderQuantity;
	}

	public BigDecimal getOrderPrice() {
		return orderPrice;
	}

	public void setOrderPrice(BigDecimal orderPrice) {
		this.orderPrice = orderPrice;
	}
	
	

}

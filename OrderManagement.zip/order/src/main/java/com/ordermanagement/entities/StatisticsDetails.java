package com.ordermanagement.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table
public class StatisticsDetails implements Serializable {

	private static final long serialVersionUID = -2516143141643380974L;

	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer statasticId;

	@Column
	private Integer soldQuantity;

	@Column
	private String instrumentId;
	
	//REMAINING_QUANTIY
	@Column
	private Integer remainingOrderQuantity;

	public Integer getRemainingOrderQuantity() {
		return remainingOrderQuantity;
	}

	public void setRemainingOrderQuantity(Integer remainingOrderQuantity) {
		this.remainingOrderQuantity = remainingOrderQuantity;
	}

	@ManyToOne()
	@JoinColumn(name = "executionId")
	@JsonBackReference
	private ExecuteData executionData;

	@ManyToOne
	@JoinColumn(name = "ORDER_ID")
	private OrderDetails orderDetails;

	public OrderDetails getOrderDetails() {
		return orderDetails;
	}

	public void setOrderDetails(OrderDetails orderDetails) {
		this.orderDetails = orderDetails;
	}

	@Column
	private Boolean isValid;

	public Integer getStatasticId() {
		return statasticId;
	}

	public void setStatasticId(Integer statasticId) {
		this.statasticId = statasticId;
	}

	public Integer getSoldQuantity() {
		return soldQuantity;
	}

	public void setSoldQuantity(Integer soldQuantity) {
		this.soldQuantity = soldQuantity;
	}

	public ExecuteData getExecutionData() {
		return executionData;
	}

	public void setExecutionData(ExecuteData executionData) {
		this.executionData = executionData;
	}

	public Boolean isValid() {
		return isValid;
	}

	public void setValid(Boolean valid) {
		this.isValid = valid;
	}

	public String getInstrumentId() {
		return instrumentId;
	}

	public void setInstrumentId(String instrumentId) {
		this.instrumentId = instrumentId;
	}

	@Override
	public String toString() {
		return "StatisticsDetails [statasticId=" + statasticId + ", soldQuantity=" + soldQuantity + ", executionData="
				+ executionData + ", orderDetails=" + orderDetails + "]";
	}

}

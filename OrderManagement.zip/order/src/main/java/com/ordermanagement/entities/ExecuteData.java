package com.ordermanagement.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table
public class ExecuteData {

	@Id
	@Column
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int executionId;
	
	@Column
	private double orderPrice;
	
	@Column
	private int orderQuantity;
	
	@Column
	private boolean status;
	
	@Column
	private Date executedDate;
	
	@Column
	private double currentAvailability;
	
	@OneToMany(mappedBy="executionData",fetch = FetchType.EAGER)
	@JsonManagedReference
	private List<StatisticsDetails> statisticsDetails;
	
	@OneToOne
	private OrderBook orderBook;

	public int getExecutionId() {
		return executionId;
	}

	public void setExecutionId(int executionId) {
		this.executionId = executionId;
	}

	public double getOrderPrice() {
		return orderPrice;
	}

	public void setOrderPrice(double orderPrice) {
		this.orderPrice = orderPrice;
	}

	public int getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Date getExecutedDate() {
		return executedDate;
	}

	public void setExecutedDate(Date executedDate) {
		this.executedDate = executedDate;
	}

	public double getCurrentAvailability() {
		return currentAvailability;
	}

	public void setCurrentAvailability(double currentAvailability) {
		this.currentAvailability = currentAvailability;
	}

	public List<StatisticsDetails> getStatisticsDetails() {
		return statisticsDetails;
	}

	public void setStatisticsDetails(List<StatisticsDetails> statisticsDetails) {
		this.statisticsDetails = statisticsDetails;
	}

	public OrderBook getOrderBook() {
		return orderBook;
	}

	public void setOrderBook(OrderBook orderBook) {
		this.orderBook = orderBook;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(currentAvailability);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((executedDate == null) ? 0 : executedDate.hashCode());
		result = prime * result + executionId;
		result = prime * result + ((orderBook == null) ? 0 : orderBook.hashCode());
		temp = Double.doubleToLongBits(orderPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + orderQuantity;
		result = prime * result + ((statisticsDetails == null) ? 0 : statisticsDetails.hashCode());
		result = prime * result + (status ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExecuteData other = (ExecuteData) obj;
		if (Double.doubleToLongBits(currentAvailability) != Double.doubleToLongBits(other.currentAvailability))
			return false;
		if (executedDate == null) {
			if (other.executedDate != null)
				return false;
		} else if (!executedDate.equals(other.executedDate))
			return false;
		if (executionId != other.executionId)
			return false;
		if (orderBook == null) {
			if (other.orderBook != null)
				return false;
		} else if (!orderBook.equals(other.orderBook))
			return false;
		if (Double.doubleToLongBits(orderPrice) != Double.doubleToLongBits(other.orderPrice))
			return false;
		if (orderQuantity != other.orderQuantity)
			return false;
		if (statisticsDetails == null) {
			if (other.statisticsDetails != null)
				return false;
		} else if (!statisticsDetails.equals(other.statisticsDetails))
			return false;
		if (status != other.status)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ExecuteData [executionId=" + executionId + ", orderPrice=" + orderPrice + ", orderQuantity="
				+ orderQuantity + ", status=" + status + ", executedDate=" + executedDate + ", currentAvailability="
				+ currentAvailability + ", statisticsDetails=" + statisticsDetails + ", orderBook=" + orderBook + "]";
	}
	
}

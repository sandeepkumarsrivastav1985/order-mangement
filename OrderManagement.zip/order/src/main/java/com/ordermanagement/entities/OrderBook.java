package com.ordermanagement.entities;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table
public class OrderBook implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 411534906679728301L;

	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int orderBookId;

	@OneToMany(mappedBy = "orderBook", fetch = FetchType.EAGER)
	@JsonManagedReference
	private Set<OrderDetails> orderList;

	@Column
	private boolean status;

	@Column(unique = true)
	private String instrumentId;

	public int getOrderBookId() {
		return orderBookId;
	}
	public OrderBook() {
		// TODO Auto-generated constructor stub
	}

	public OrderBook(String instrumentId,int orderBookId, Set<OrderDetails> orderList, boolean status ) {
		super();
		this.orderBookId = orderBookId;
		this.orderList = orderList;
		this.status = status;
		this.instrumentId = instrumentId;
	}
	public void setOrderBookId(int orderBookId) {
		this.orderBookId = orderBookId;
	}

	public Set<OrderDetails> getOrderList() {
		return orderList;
	}

	public void setOrderList(Set<OrderDetails> orderList) {
		this.orderList = orderList;
	}

	public boolean getStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getInstrumentId() {
		return instrumentId;
	}

	public void setInstrumentId(String instrumentId) {
		this.instrumentId = instrumentId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + orderBookId;
		result = prime * result + ((orderList == null) ? 0 : orderList.hashCode());
		result = prime * result + (status ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderBook other = (OrderBook) obj;
		if (orderBookId != other.orderBookId)
			return false;
		if (orderList == null) {
			if (other.orderList != null)
				return false;
		} else if (!orderList.equals(other.orderList))
			return false;
		if (status != other.status)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "OrderBook [orderBookId=" + orderBookId + ", status=" + status + ", instrumentName=" + instrumentId
				+ "]";
	}

}

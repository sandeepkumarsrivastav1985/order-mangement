package com.ordermanagement.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.ordermanagement.contracts.OrderDetailsPojo;

@Entity
@Table
public class OrderDetails implements Serializable, Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2391486811398436373L;

	public OrderDetails() {
	}

	public OrderDetails(OrderDetailsPojo order) {
		this.orderId = order.getOrderId();
		this.orderQuantity = order.getOrderQuantity();
		this.initialOrderQuantity = order.getOrderQuantity();
		this.entryDate = LocalDate.now();
		this.orderPrice = order.getOrderPrice();
		this.priceType = order.getPriceType();
		this.orderBook = order.getOrderBook();
	}

	public OrderDetails(int orderId, int orderQuantity, int initialOrderQuantity, LocalDate entryDate, BigDecimal orderPrice,
			String priceType, OrderBook orderBook) {
		super();
		this.orderId = orderId;
		this.orderQuantity = orderQuantity;
		this.initialOrderQuantity = initialOrderQuantity;
		this.entryDate = LocalDate.now();
		this.orderPrice = orderPrice;
		this.priceType = priceType;
		this.orderBook = orderBook;
	}

	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int orderId;

	@Column
	private int orderQuantity;

	@Column
	private int initialOrderQuantity;

	@Column(name = "ENTRY_DATE", nullable = true)
    @Type(type = "java.time.LocalDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class) 
	private LocalDate entryDate;

	@Column
	private BigDecimal orderPrice;

	@Column
	private String priceType;

	@ManyToOne
	@JoinColumn(name = "orderBookId")
	@JsonBackReference
	private OrderBook orderBook;

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public LocalDate getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(LocalDate entryDate) {
		this.entryDate = entryDate;
	}

	public BigDecimal getOrderPrice() {
		return orderPrice;
	}

	public void setOrderPrice(BigDecimal orderPrice) {
		this.orderPrice = orderPrice;
	}

	public String getPriceType() {
		return priceType;
	}

	public void setPriceType(String priceType) {
		this.priceType = priceType;
	}

	public OrderBook getOrderBook() {
		return orderBook;
	}

	public void setOrderBook(OrderBook orderBook) {
		this.orderBook = orderBook;
	}

	public int getInitialOrderQuantity() {
		return initialOrderQuantity;
	}

	public void setInitialOrderQuantity(int initialOrderQuantity) {
		this.initialOrderQuantity = initialOrderQuantity;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	@Override
	public String toString() {
		return "OrderDetails [orderId=" + orderId + ", orderQuantity=" + orderQuantity + ", entryDate=" + entryDate
				+ ", orderPrice=" + orderPrice + ", priceType=" + priceType + ", orderBook=" + orderBook + "]";
	}
}

package com.ordermanagement.entities;



import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table
public class OrderDetails implements Serializable,Cloneable {

	public OrderDetails() {}
	
	@Id
	@Column
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int orderId;
	
	@Column
	private int orderQuantity;
	
	@Column
	private Date entryDate;
	
	@Column
	private BigDecimal orderPrice;
	
	@Column
	private String priceType;
	
	@ManyToOne
	@JoinColumn(name="orderBookId")
	@JsonBackReference
	private OrderBook orderBook;

	public int getOrderId() {
		return orderId;
	}


	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}


	public int getOrderQuantity() {
		return orderQuantity;
	}


	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}


	public Date getEntryDate() {
		return entryDate;
	}


	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}


	public BigDecimal getOrderPrice() {
		return orderPrice;
	}


	public void setOrderPrice(BigDecimal orderPrice) {
		this.orderPrice = orderPrice;
	}


	public String getPriceType() {
		return priceType;
	}


	public void setPriceType(String priceType) {
		this.priceType = priceType;
	}

	public OrderBook getOrderBook() {
		return orderBook;
	}


	public void setOrderBook(OrderBook orderBook) {
		this.orderBook = orderBook;
	}




	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	
	@Override
	public String toString() {
		return "OrderDetails [orderId=" + orderId + ", orderQuantity=" + orderQuantity + ", entryDate=" + entryDate
				+ ", orderPrice=" + orderPrice + ", priceType=" + priceType 
				+ ", orderBook=" + orderBook + "]";
	}
}

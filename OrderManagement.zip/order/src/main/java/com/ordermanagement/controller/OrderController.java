package com.ordermanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ordermanagement.contracts.OrderBookPojo;
import com.ordermanagement.contracts.OrderDetailsPojo;
import com.ordermanagement.services.OrderService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/orders")
@Api(value = "order", description = "Operations pertaining to instrument in OrderManagement System")
public class OrderController {

	@Autowired
	OrderService orderService;

	@ApiOperation(value = "View a list of available available Order Books.", response = Iterable.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping(value = "/allOrderBooks", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<OrderBookPojo> getAllOrderBook() {
		List<OrderBookPojo> orderBooks = orderService.getAllOrderBook();
		return orderBooks;
	}

	@ApiOperation(value = "Add Instruent Details like price, quantity and price type for the Instrument.")
	@PostMapping(value = "/addOrder", produces = MediaType.APPLICATION_JSON_VALUE)
	public OrderDetailsPojo addOrder(@RequestBody OrderDetailsPojo order) {
		return orderService.addOrder(order);

	}

	@ApiOperation(value = "Change Order Book Status(Close or Open the order book)")
	@PostMapping(value = "/changeOrderBookStatus", produces = MediaType.APPLICATION_JSON_VALUE)
	public OrderBookPojo changeOrderBookStatus(@RequestBody OrderBookPojo orderBook) {
		return orderService.updateOrderBook(orderBook);
	}

	@ApiOperation(value = "Add Order Book for an Instrument")
	@PostMapping(value = "/addInstrument", produces = MediaType.APPLICATION_JSON_VALUE)
	public OrderBookPojo createNewOrderBook(@RequestBody OrderBookPojo orderBook) {
		OrderBookPojo orderBookPojo = orderService.addOrderBook(orderBook);
		return orderBookPojo;

	}
}

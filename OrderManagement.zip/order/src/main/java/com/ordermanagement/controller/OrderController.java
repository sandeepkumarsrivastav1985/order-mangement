package com.ordermanagement.controller;


import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ordermanagement.entities.OrderBook;
import com.ordermanagement.entities.OrderDetails;
import com.ordermanagement.service.OrderService;

@RestController
@RequestMapping("/orders")
public class OrderController {
	
	@Autowired
	OrderService orderService;
	
	@GetMapping(value="/allOrderBooks" , produces =  MediaType.APPLICATION_JSON_VALUE)
	public List<OrderBook> getAllOrderBook() {
		List<OrderBook> orderBooks= orderService.getAllOrderBook();
		return orderBooks;
	}
	
	@PostMapping(value="/addOrder", produces =  MediaType.APPLICATION_JSON_VALUE )
	public OrderDetails addOrder(@RequestBody OrderDetails order) {
		order.setEntryDate(new Date());
		return orderService.addOrder(order);
		
	}
	
	@PostMapping(value="/changeOrderBookStatus", produces =  MediaType.APPLICATION_JSON_VALUE )
	public OrderBook changeOrderBookStatus(@RequestBody OrderBook orderBook) {
		return orderService.updateOrderBook(orderBook);
		
	}

	@PostMapping(value="/createOrderBook", produces =  MediaType.APPLICATION_JSON_VALUE )
	public OrderBook createNewOrderBook(@RequestBody OrderBook orderBook) {
		orderBook.setStatus(true);
		return orderService.addOrderBook(orderBook);
		
	}
}

package com.ordermanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;

import com.ordermanagement.entities.StatisticsDetails;
import com.ordermanagement.service.StatisticService;

public class OrderStatisticController {
	
	@Autowired
	StatisticService staticService;
	
	@GetMapping(value="/statisticOrderDetails", produces =  MediaType.APPLICATION_JSON_VALUE )
	public String getStatisticOrderDetails() throws CloneNotSupportedException {
		List<StatisticsDetails> executeOrder=staticService.getDataForStatistic();
		System.out.println(executeOrder);
		return "Success";
		
	}

}

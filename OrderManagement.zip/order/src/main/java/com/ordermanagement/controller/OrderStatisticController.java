package com.ordermanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ordermanagement.contracts.Execute;
import com.ordermanagement.contracts.LimitBreakDown;
import com.ordermanagement.contracts.Statistic;
import com.ordermanagement.dao.OrderDetailsForStats;
import com.ordermanagement.entities.OrderDetailsForStatistic;
import com.ordermanagement.services.StatisticService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/statistics")
@Api(value = "statistics", description = "Operations to retrieve statistics")
public class OrderStatisticController {

	@Autowired
	StatisticService statisticsService;

	@ApiOperation(value = "Statistics related to Order Details", response = Iterable.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping(value = "/allOrderDetailsForStat", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<OrderDetailsForStats> getAllOrderDetailsForStat() {
		List<OrderDetailsForStats> executedData = statisticsService.getAllOrderDetails();
		return executedData;
	}

	@ApiOperation(value = "Statistics related to Execution", response = Iterable.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping(value = "/getAllExecutionsDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Execute> getAllExecutionsDetails() {
		
		return statisticsService.getAllExecutionsDetails();
	}

	@ApiOperation(value = "Statistics related to Execution", response = Iterable.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping(value = "/getAllExecutionsDetailsForStats", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Statistic> getAllExecutionsDetailsForStats() {
		return statisticsService.getAllExecutionsDetailsForStats();
	}
	
	@ApiOperation(value = "Statistics related to Execution", response = Iterable.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping(value = "/getLimitBreakDownForStats", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<LimitBreakDown> getLimitBreakDownForStats() {
		return statisticsService.getLimitBreakDownForStats();
	}
	
	@ApiOperation(value = "Statistics related to Execution", response = Iterable.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping(value = "/getAllOrderDataForStats", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<OrderDetailsForStatistic> getAllOrderDataForStats() {
		return statisticsService.getAllOrderDataForStats();
	}
	
	
}

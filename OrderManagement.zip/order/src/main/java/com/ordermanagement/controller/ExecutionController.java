package com.ordermanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ordermanagement.contracts.Execute;
import com.ordermanagement.services.ExecutionService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/execute")
@Api(value = "execution", description = "Operations pertaining to execution of orders")
public class ExecutionController {

	@Autowired
	ExecutionService executionService;

	@ApiOperation(value = "Execute Orders for given price and quantity")
	@PostMapping(value = "/executeOrder", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Execute> addOrder(@RequestBody List<Execute> executeList) throws CloneNotSupportedException {
		executionService.executeOrder(executeList);
		return executeList;

	}

}

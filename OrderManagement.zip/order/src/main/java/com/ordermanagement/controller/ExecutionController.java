package com.ordermanagement.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ordermanagement.contracts.Execute;
import com.ordermanagement.dao.OrderDetailsForStats;
import com.ordermanagement.entities.ExecuteData;
import com.ordermanagement.entities.OrderDetails;
import com.ordermanagement.service.ExecutionService;

@RestController
@RequestMapping("/execute")
public class ExecutionController {

	@Autowired
	ExecutionService executionService;
	
	@PostMapping(value="/executeOrder", produces =  MediaType.APPLICATION_JSON_VALUE )
	public Map<ExecuteData, List<OrderDetails>> addOrder(@RequestBody List<Execute> executeList) throws CloneNotSupportedException {
		Map<ExecuteData, List<OrderDetails>> executeOrder=executionService.executeOrder(executeList);
		
		return executeOrder;
		
	}
	
	@GetMapping(value="/allExecutedData" , produces =  MediaType.APPLICATION_JSON_VALUE)
	public List<ExecuteData> getAllOrderBook() {
		List<ExecuteData> executedData= executionService.getAllExecutedData();
		return executedData;
	}
	
	@GetMapping(value="/allOrderDetailsForStat" , produces =  MediaType.APPLICATION_JSON_VALUE)
	public List<OrderDetailsForStats> getAllOrderDetailsForStat() {
		List<OrderDetailsForStats> executedData= executionService.getAllOrderDetails();
		return executedData;
	}
}

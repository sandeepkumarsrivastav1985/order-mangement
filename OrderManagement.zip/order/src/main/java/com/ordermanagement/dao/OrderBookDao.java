package com.ordermanagement.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ordermanagement.entities.OrderBook;

public interface OrderBookDao extends JpaRepository<OrderBook, Integer>{

}

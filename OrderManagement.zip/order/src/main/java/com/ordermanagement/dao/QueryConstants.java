package com.ordermanagement.dao;

public class QueryConstants {

	public static final String GET_ALL_ORDER_DETAILS = "SELECT c.*," + "       (SELECT Min(b.order_id)"
			+ "        FROM   order_details b" + "        WHERE  b.order_book_id = c.orderBookId"
			+ "               AND b.order_quantity = c.biggestOrder) as biggestOrderId, "
			+ "       (SELECT Min(b.order_id)" + "        FROM   order_details b"
			+ "        WHERE  b.order_book_id = c.orderBookId"
			+ "               AND b.order_quantity = c.smallestOrder) as smallestOrderId,"
			+ "       (SELECT Min(b.order_id)" + "        FROM   order_details b"
			+ "        WHERE  b.order_book_id = c.orderBookId"
			+ "               AND b.entry_date = c.earliestOrder) as earliestOrderId,"
			+ "       (SELECT Max(b.order_id)" + "        FROM   order_details b"
			+ "        WHERE  b.order_book_id = c.orderBookId"
			+ "               AND b.entry_date = c.lastOrder)   as     lastOrderId"
			+ "	FROM   (SELECT a.instrument_id as bookName," + " 				 a.order_book_id as orderBookId, "
			+ "               (SELECT SUM(b.order_quantity)" + "                FROM   order_details b"
			+ "                WHERE  b.order_book_id = a.order_book_id) as orderQuantity,"
			+ "               (SELECT Max(b.order_quantity)" + "                FROM   order_details b"
			+ "                WHERE  b.order_book_id = a.order_book_id) as biggestOrder,"
			+ "               (SELECT Min(b.order_quantity)" + "                FROM   order_details b"
			+ "                WHERE  b.order_book_id = a.order_book_id) as smallestOrder,"
			+ "               (SELECT Min(b.entry_date)" + "                FROM   order_details b"
			+ "                WHERE  b.order_book_id = a.order_book_id) as earliestOrder,"
			+ "               (SELECT Max(b.entry_date)" + "                FROM   order_details b"
			+ "                WHERE  b.order_book_id = a.order_book_id) as lastOrder,"
			+ "               Ifnull((SELECT SUM(b.order_quantity)" + "                       FROM   execute_data b"
			+ "                       WHERE  b.order_book_order_book_id = a.order_book_id"
			+ "                              AND b.status = 1), 0) as  demand" + "        FROM   order_book a)c ";

	public static final String GET_LIMIT_BREAK_DOWN = "SELECT ORDER_PRICE AS price,SUM(ORDER_QUANTITY) AS demand , "
			+ "ORDER_BOOK_ID as orderBookId FROM ORDER_DETAILS GROUP BY ORDER_BOOK_ID,ORDER_PRICE ORDER BY ORDER_BOOK_ID ASC";

	public static final String GET_ALL_OREDER_DETAILS = "SELECT ORDER_BOOK_ID as initialOrderQuantity , ORDER_ID as orderId , ORDER_PRICE AS orderPrice, ORDER_QUANTITY as orderQuantity  "
			+ " FROM ORDER_DETAILS ORDER BY ORDER_BOOK_ID ASC";

	public static final String GET_ALL_EXECUTION_ORDER_DETAILS = "SELECT  sd.EXECUTION_ID as executionId,od.order_BOOK_ID as orderBookId,od.order_ID as orderId, "
			+ "sd.SOLD_QUANTITY as soldQuantity,sd.REMAINING_ORDER_QUANTITY as remainingOrderQuantity ,od.ORDER_PRICE as orderPrice,sd.IS_VALID as status FROM  "
			+ "STATISTICS_DETAILS sd INNER JOIN ORDER_DETAILS od ON od.order_ID = sd.order_ID";
}

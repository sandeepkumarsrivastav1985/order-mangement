package com.ordermanagement.dao;

public class QueryConstants {

	public static final String GET_ALL_ORDER_DETAILS="SELECT c.*," + 
			"       (SELECT Min(b.order_id)" + 
			"        FROM   order_details b" + 
			"        WHERE  b.order_book_id = c.orderBookId" + 
			"               AND b.order_quantity = c.biggestOrder) as biggestOrderId," + 
			"       (SELECT Min(b.order_id)" + 
			"        FROM   order_details b" + 
			"        WHERE  b.order_book_id = c.orderBookId" + 
			"               AND b.order_quantity = c.smallestOrder) as smallestOrderId," + 
			"       (SELECT Min(b.order_id)" + 
			"        FROM   order_details b" + 
			"        WHERE  b.order_book_id = c.orderBookId" + 
			"               AND b.entry_date = c.earliestOrder) as earliestOrderId," + 
			"       (SELECT Max(b.order_id)" + 
			"        FROM   order_details b" + 
			"        WHERE  b.order_book_id = c.orderBookId" + 
			"               AND b.entry_date = c.lastOrder)   as     lastOrderId" + 
			"	FROM   (SELECT a.name as bookName," + 
			" 				 a.order_book_id as orderBookId, "+
			"               (SELECT SUM(b.order_quantity)" + 
			"                FROM   order_details b" + 
			"                WHERE  b.order_book_id = a.order_book_id) as orderQuantity," + 
			"               (SELECT Max(b.order_quantity)" + 
			"                FROM   order_details b" + 
			"                WHERE  b.order_book_id = a.order_book_id) as biggestOrder," + 
			"               (SELECT Min(b.order_quantity)" + 
			"                FROM   order_details b" + 
			"                WHERE  b.order_book_id = a.order_book_id) as smallestOrder," + 
			"               (SELECT Min(b.entry_date)" + 
			"                FROM   order_details b" + 
			"                WHERE  b.order_book_id = a.order_book_id) as earliestOrder," + 
			"               (SELECT Max(b.entry_date)" + 
			"                FROM   order_details b" + 
			"                WHERE  b.order_book_id = a.order_book_id) as lastOrder," + 
			"               Ifnull((SELECT SUM(b.order_quantity)" + 
			"                       FROM   execute_data b" + 
			"                       WHERE  b.order_book_order_book_id = a.order_book_id" + 
			"                              AND b.status = 1), 0) as  demand" + 
			"        FROM   order_book a)c ";
}

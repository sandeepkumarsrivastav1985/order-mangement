package com.ordermanagement.dao;

import org.springframework.stereotype.Repository;

@Repository
public class ExecutionDAO {

}

package com.ordermanagement.dao;

import java.util.Date;

public class OrderDetailsForStats {
	public OrderDetailsForStats(){}
	private String bookName;
	private int orderBookId;
	private int orderQuantity;
	private int biggestOrder;
	private int smallestOrder;
	private Date earliestOrder;
	private Date lastOrder;
	private int biggestOrderId;
	private int smallestOrderId;
	private int earliestOrderId;
	private int lastOrderId;
	private int demand;
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public int getOrderBookId() {
		return orderBookId;
	}
	public void setOrderBookId(int orderBookId) {
		this.orderBookId = orderBookId;
	}
	public int getOrderQuantity() {
		return orderQuantity;
	}
	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}
	public int getBiggestOrder() {
		return biggestOrder;
	}
	public void setBiggestOrder(int biggestOrder) {
		this.biggestOrder = biggestOrder;
	}
	public int getSmallestOrder() {
		return smallestOrder;
	}
	public void setSmallestOrder(int smallestOrder) {
		this.smallestOrder = smallestOrder;
	}
	public Date getEarliestOrder() {
		return earliestOrder;
	}
	public void setEarliestOrder(Date earliestOrder) {
		this.earliestOrder = earliestOrder;
	}
	public Date getLastOrder() {
		return lastOrder;
	}
	public void setLastOrder(Date lastOrder) {
		this.lastOrder = lastOrder;
	}
	public int getBiggestOrderId() {
		return biggestOrderId;
	}
	public void setBiggestOrderId(int biggestOrderId) {
		this.biggestOrderId = biggestOrderId;
	}
	public int getSmallestOrderId() {
		return smallestOrderId;
	}
	public void setSmallestOrderId(int smallestOrderId) {
		this.smallestOrderId = smallestOrderId;
	}
	public int getEarliestOrderId() {
		return earliestOrderId;
	}
	public void setEarliestOrderId(int earliestOrderId) {
		this.earliestOrderId = earliestOrderId;
	}
	public int getLastOrderId() {
		return lastOrderId;
	}
	public void setLastOrderId(int lastOrderId) {
		this.lastOrderId = lastOrderId;
	}
	public int getDemand() {
		return demand;
	}
	public void setDemand(int demand) {
		this.demand = demand;
	}
	
}

package com.ordermanagement.dao;

import java.util.Date;

public class OrderDetailsForStats {
	public OrderDetailsForStats(){}
	private String bookName;
	private Integer orderBookId;
	private Integer orderQuantity;
	private Integer biggestOrder;
	private Integer smallestOrder;
	private Date earliestOrder;
	private Date lastOrder;
	private Integer biggestOrderId;
	private Integer smallestOrderId;
	private Integer earliestOrderId;
	private Integer lastOrderId;
	private Integer demand;
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public Integer getOrderBookId() {
		return orderBookId;
	}
	public void setOrderBookId(Integer orderBookId) {
		this.orderBookId = orderBookId;
	}
	public Integer getOrderQuantity() {
		return orderQuantity;
	}
	public void setOrderQuantity(Integer orderQuantity) {
		this.orderQuantity = orderQuantity;
	}
	public Integer getBiggestOrder() {
		return biggestOrder;
	}
	public void setBiggestOrder(Integer biggestOrder) {
		this.biggestOrder = biggestOrder;
	}
	public Integer getSmallestOrder() {
		return smallestOrder;
	}
	public void setSmallestOrder(Integer smallestOrder) {
		this.smallestOrder = smallestOrder;
	}
	public Date getEarliestOrder() {
		return earliestOrder;
	}
	public void setEarliestOrder(Date earliestOrder) {
		this.earliestOrder = earliestOrder;
	}
	public Date getLastOrder() {
		return lastOrder;
	}
	public void setLastOrder(Date lastOrder) {
		this.lastOrder = lastOrder;
	}
	public Integer getBiggestOrderId() {
		return biggestOrderId;
	}
	public void setBiggestOrderId(Integer biggestOrderId) {
		this.biggestOrderId = biggestOrderId;
	}
	public Integer getSmallestOrderId() {
		return smallestOrderId;
	}
	public void setSmallestOrderId(Integer smallestOrderId) {
		this.smallestOrderId = smallestOrderId;
	}
	public Integer getEarliestOrderId() {
		return earliestOrderId;
	}
	public void setEarliestOrderId(Integer earliestOrderId) {
		this.earliestOrderId = earliestOrderId;
	}
	public Integer getLastOrderId() {
		return lastOrderId;
	}
	public void setLastOrderId(Integer lastOrderId) {
		this.lastOrderId = lastOrderId;
	}
	public Integer getDemand() {
		return demand;
	}
	public void setDemand(Integer demand) {
		this.demand = demand;
	}
	
}

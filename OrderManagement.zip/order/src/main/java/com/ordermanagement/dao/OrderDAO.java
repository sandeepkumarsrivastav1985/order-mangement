package com.ordermanagement.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.type.DateType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.github.fluent.hibernate.transformer.FluentHibernateResultTransformer;
import com.ordermanagement.contracts.Execute;
import com.ordermanagement.entities.OrderBook;
import com.ordermanagement.entities.OrderDetails;

@Repository
public class OrderDAO {
	
	@Autowired
	SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	public List<OrderDetails> getOrderDettails(Execute execute) {
		return (List<OrderDetails>)this.sessionFactory.getCurrentSession()
				.createSQLQuery(
						"select a.* from Order_Details a, Order_Book b where a.order_Book_Id=b.order_Book_Id and a.order_Price=:orderPrice and b.order_Book_Id=:orderBookId order by a.order_Quantity desc")
				.addEntity(OrderDetails.class)
				.setParameter("orderPrice", execute.getPrice()).setParameter("orderBookId", execute.getOrderBookId())
				.list();
	}
	

	public void updateOrderDetails(OrderDetails order) {
		this.sessionFactory.getCurrentSession().update(order);
	}

	@SuppressWarnings("unchecked")
	public List<OrderDetailsForStats> getAllOrderDetailsForStats() {
		Query q=this.sessionFactory.getCurrentSession().createSQLQuery(QueryConstants.GET_ALL_ORDER_DETAILS)
				.addScalar("bookName",StringType.INSTANCE)
				.addScalar("orderBookId",IntegerType.INSTANCE)
				.addScalar("orderQuantity",IntegerType.INSTANCE)
				.addScalar("biggestOrder",IntegerType.INSTANCE)
				.addScalar("smallestOrder",IntegerType.INSTANCE)
				.addScalar("earliestOrder",DateType.INSTANCE)
				.addScalar("lastOrder",DateType.INSTANCE)
				.addScalar("demand",IntegerType.INSTANCE)
				.addScalar("biggestOrderId",IntegerType.INSTANCE)
				.addScalar("smallestOrderId",IntegerType.INSTANCE)
				.addScalar("earliestOrderId",IntegerType.INSTANCE)
				.addScalar("lastOrderId",IntegerType.INSTANCE);;
		
		List<OrderDetailsForStats> lst= q.setResultTransformer(new FluentHibernateResultTransformer(OrderDetailsForStats.class)).list();
			return lst	;
		 
	}

}

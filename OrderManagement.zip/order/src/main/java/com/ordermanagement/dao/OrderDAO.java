package com.ordermanagement.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.type.BigDecimalType;
import org.hibernate.type.BooleanType;
import org.hibernate.type.DateType;
import org.hibernate.type.DoubleType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.github.fluent.hibernate.transformer.FluentHibernateResultTransformer;
import com.ordermanagement.contracts.Execute;
import com.ordermanagement.contracts.LimitBreakDown;
import com.ordermanagement.contracts.Statistic;
import com.ordermanagement.entities.OrderDetails;

@Repository
public class OrderDAO {

	@Autowired
	SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	public List<OrderDetails> getOrderDettails(Execute execute) {
		return (List<OrderDetails>) this.sessionFactory.getCurrentSession().createSQLQuery(
				"select a.* from Order_Details a, Order_Book b where a.order_Book_Id=b.order_Book_Id and a.order_Price>=:orderPrice and b.order_Book_Id=:orderBookId order by a.order_Quantity desc")
				.addEntity(OrderDetails.class).setParameter("orderPrice", execute.getPrice())
				.setParameter("orderBookId", execute.getOrderBookId()).list();
	}
	
	@SuppressWarnings("unchecked")
	public List<OrderDetails> getOrderDettailsforInvalid(Execute execute) {
		return (List<OrderDetails>) this.sessionFactory.getCurrentSession().createSQLQuery(
				"select a.* from Order_Details a, Order_Book b where a.order_Book_Id=b.order_Book_Id and a.order_Price < :orderPrice and b.order_Book_Id=:orderBookId order by a.order_Quantity desc")
				.addEntity(OrderDetails.class).setParameter("orderPrice", execute.getPrice())
				.setParameter("orderBookId", execute.getOrderBookId()).list();
	}

	public void updateOrderDetails(OrderDetails order) {
		this.sessionFactory.getCurrentSession().update(order);
	}

	@SuppressWarnings("unchecked")
	public List<OrderDetailsForStats> getAllOrderDetailsForStats() {
		Query q = this.sessionFactory.getCurrentSession().createSQLQuery(QueryConstants.GET_ALL_ORDER_DETAILS)
				.addScalar("bookName", StringType.INSTANCE).addScalar("orderBookId", IntegerType.INSTANCE)
				.addScalar("orderQuantity", IntegerType.INSTANCE).addScalar("biggestOrder", IntegerType.INSTANCE)
				.addScalar("smallestOrder", IntegerType.INSTANCE).addScalar("earliestOrder", DateType.INSTANCE)
				.addScalar("lastOrder", DateType.INSTANCE).addScalar("demand", IntegerType.INSTANCE)
				.addScalar("biggestOrderId", IntegerType.INSTANCE).addScalar("smallestOrderId", IntegerType.INSTANCE)
				.addScalar("earliestOrderId", IntegerType.INSTANCE).addScalar("lastOrderId", IntegerType.INSTANCE);
		;

		List<OrderDetailsForStats> lst = q
				.setResultTransformer(new FluentHibernateResultTransformer(OrderDetailsForStats.class)).list();
		return lst;

	}

	@SuppressWarnings("unchecked")
	public List<LimitBreakDown> getLimitBreakDownForStats() {
		Query q = this.sessionFactory.getCurrentSession().createSQLQuery(QueryConstants.GET_LIMIT_BREAK_DOWN)
				.addScalar("orderBookId",IntegerType.INSTANCE).addScalar("demand",IntegerType.INSTANCE).addScalar("price",DoubleType.INSTANCE);
		
		List<LimitBreakDown> lst = q
				.setResultTransformer(new FluentHibernateResultTransformer(LimitBreakDown.class)).list();
		return lst;
	}
	
	@SuppressWarnings("unchecked")
	public List<com.ordermanagement.contracts.OrderDetails> getAllOrderDataForStats() {
		Query q = this.sessionFactory.getCurrentSession().createSQLQuery(QueryConstants.GET_ALL_OREDER_DETAILS)
				.addScalar("initialOrderQuantity",IntegerType.INSTANCE).addScalar("orderId",IntegerType.INSTANCE).addScalar("orderPrice",BigDecimalType.INSTANCE).addScalar("orderQuantity",IntegerType.INSTANCE);
		
		List<com.ordermanagement.contracts.OrderDetails> lst = q
				.setResultTransformer(new FluentHibernateResultTransformer(com.ordermanagement.contracts.OrderDetails.class)).list();
		
		return lst;
	}
	@SuppressWarnings("unchecked")
	public List<Statistic> getAllExecutionsDetailsForStats() {
		Query q = this.sessionFactory.getCurrentSession().createSQLQuery(QueryConstants.GET_ALL_EXECUTION_ORDER_DETAILS).addScalar("executionId",IntegerType.INSTANCE)
				.addScalar("orderBookId",IntegerType.INSTANCE).addScalar("orderId",IntegerType.INSTANCE).addScalar("soldQuantity",IntegerType.INSTANCE).addScalar("remainingOrderQuantity",IntegerType.INSTANCE)
				.addScalar("orderPrice",BigDecimalType.INSTANCE).addScalar("status",BooleanType.INSTANCE);
		
		List<Statistic> lst = q
				.setResultTransformer(new FluentHibernateResultTransformer(Statistic.class)).list();
		
		return lst;
	}

}

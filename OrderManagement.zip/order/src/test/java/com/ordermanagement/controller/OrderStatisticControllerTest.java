package com.ordermanagement.controller;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.ordermanagement.contracts.Execute;
import com.ordermanagement.contracts.LimitBreakDown;
import com.ordermanagement.contracts.Statistic;
import com.ordermanagement.entities.OrderDetailsForStatistic;
import com.ordermanagement.service.impl.StatisticServiceImpl;

@RunWith(SpringRunner.class)
@WebMvcTest(value = OrderStatisticController.class, secure = false)
public class OrderStatisticControllerTest {

	
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private StatisticServiceImpl statisticService;

	ArrayList<OrderDetailsForStatistic> mockOrderDetailsForStatistic = new ArrayList<OrderDetailsForStatistic>();
	
	List<Execute> mockExecutionList = new ArrayList<>();
	
	List<Statistic> mockListStatistic = new ArrayList<>();
	
	List<LimitBreakDown> mockListLimitBreakDown = new ArrayList<>();

	String exampleCourseJson = "[{\"orderId\":null,\"orderQuantity\":null,\"initialOrderQuantity\":null,\"orderPrice\":null}]";


	@Before
	public void setup() {
		mockOrderDetailsForStatistic.add(new OrderDetailsForStatistic());
		
	}
	
	@Test
	public final void testGetAllOrderDetailsForStat() throws Exception {
		Mockito.when(statisticService.getAllOrderDataForStats()).thenReturn(mockOrderDetailsForStatistic);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/statistics/allOrderDetailsForStat")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		JSONAssert.assertEquals("[]", result.getResponse().getContentAsString(), false);

	}
	
	@Test
	public final void testGetAllExecutionsDetails() throws Exception {
		Mockito.when(statisticService.getAllExecutionsDetails()).thenReturn(mockExecutionList);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/statistics/getAllExecutionsDetails")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		JSONAssert.assertEquals("[]", result.getResponse().getContentAsString(), false);
		//System.out.println(result.getResponse().getContentAsString());

	}

	@Test
	public final void testGetAllExecutionsDetailsForStats() throws Exception {
		Mockito.when(statisticService.getAllExecutionsDetailsForStats()).thenReturn(mockListStatistic);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/statistics/getAllExecutionsDetailsForStats")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		JSONAssert.assertEquals("[]", result.getResponse().getContentAsString(), false);

	}
	
	@Test
	public final void testGetLimitBreakDownForStats() throws Exception {
		Mockito.when(statisticService.getLimitBreakDownForStats()).thenReturn(mockListLimitBreakDown);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/statistics/getLimitBreakDownForStats")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		JSONAssert.assertEquals("[]", result.getResponse().getContentAsString(), false);

	}
	
	@Test
	public final void testGetAllOrderDataForStats() throws Exception {
		Mockito.when(statisticService.getAllOrderDataForStats()).thenReturn(mockOrderDetailsForStatistic);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/statistics/getAllOrderDataForStats")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		System.out.println(result.getResponse().getContentAsString());
		JSONAssert.assertEquals(exampleCourseJson, result.getResponse().getContentAsString(), false);

	}
	
	
}

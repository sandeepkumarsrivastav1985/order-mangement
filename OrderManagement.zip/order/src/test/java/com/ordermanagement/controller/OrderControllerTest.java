package com.ordermanagement.controller;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ordermanagement.contracts.OrderBookPojo;
import com.ordermanagement.contracts.OrderDetailsPojo;
import com.ordermanagement.entities.OrderBook;
import com.ordermanagement.service.impl.OrderServiceImpl;

@RunWith(SpringRunner.class)
@WebMvcTest(value = OrderController.class, secure = false)
public class OrderControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private OrderServiceImpl orderService;

	ArrayList<OrderBookPojo> mockOrderBook = new ArrayList<OrderBookPojo>();

	String exampleCourseJson = "{\"orderBookId\":1,\"orderList\":null,\"status\":true,\"instrumentId\":\"5\"}";

	@Autowired
	private ObjectMapper objectMapper;

	@Before
	public void setup() {
		mockOrderBook.add(new OrderBookPojo(1, null, true, "5"));
	}

	@Test
	public final void testGetAllOrderBook() throws Exception {
		Mockito.when(orderService.getAllOrderBook()).thenReturn(mockOrderBook);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/orders/allOrderBooks")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		System.out.println(result.getResponse().getContentAsString());
		String expected = "[{\"orderBookId\":1,\"orderList\":null,\"status\":true,\"instrumentId\":\"5\"}]";
		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);

	}

	@Test
	public final void testAddOrder() throws Exception {
		OrderDetailsPojo mockOrderBook = new OrderDetailsPojo(1, 1, 1, null, new BigDecimal(4), "1", null,
				new OrderBook());
		System.out.println(objectMapper.writeValueAsString(mockOrderBook));
		Mockito.when(orderService.addOrder(Mockito.anyObject())).thenReturn(mockOrderBook);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/orders/addOrder")
				.accept(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(mockOrderBook))
				.contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertEquals(HttpStatus.OK.value(), response.getStatus());
	}

	@Test
	public final void testChangeOrderBookStatus() throws Exception {
		Mockito.when(orderService.updateOrderBook(Mockito.any())).thenReturn(mockOrderBook.get(0));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/orders/changeOrderBookStatus")
				.content(objectMapper.writeValueAsString(mockOrderBook.get(0))).accept(MediaType.APPLICATION_JSON)
				.contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		System.out.println(result.getResponse().getContentAsString());

		String expected = "{\"orderBookId\":1,\"orderList\":null,\"status\":true,\"instrumentId\":\"5\"}";
		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);
	}
}

package com.ordermanagement.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.ArrayList;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.ordermanagement.contracts.OrderBookPojo;
import com.ordermanagement.contracts.OrderDetailsPojo;
import com.ordermanagement.entities.OrderBook;
import com.ordermanagement.entities.OrderDetails;
import com.ordermanagement.service.OrderService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = OrderController.class, secure = false)
public class OrderControllerTest {
	
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private OrderService orderService;

	ArrayList<OrderBookPojo> mockOrderBook = new ArrayList<OrderBookPojo>();

	String exampleCourseJson = "{\"name\":\"Spring\",\"description\":\"10 Steps\",\"steps\":[\"Learn Maven\",\"Import Project\",\"First Example\",\"Second Example\"]}";


	@Test
	public final void testGetAllOrderBook() throws Exception {
		Mockito.when(
				orderService.getAllOrderBook()).thenReturn(mockOrderBook);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/orders/allOrderBooks").accept(
				MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		System.out.println(result.getResponse());
		String expected = "{id:Course1,name:Spring,description:10 Steps}";
		JSONAssert.assertEquals(expected, result.getResponse()
				.getContentAsString(), false);

	}

	@Test
	public final void testAddOrder() throws Exception {
		OrderDetailsPojo mockOrderBook = new OrderDetailsPojo();
		Mockito.when(
				orderService.addOrder(Mockito.anyObject())).thenReturn(mockOrderBook);
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/orders/addOrder").accept(
				MediaType.APPLICATION_JSON).content(exampleCourseJson)
				.contentType(MediaType.APPLICATION_JSON);
		
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		System.out.println(result.getResponse());
		
		MockHttpServletResponse response = result.getResponse();

		assertEquals(HttpStatus.CREATED.value(), response.getStatus());

		assertEquals("http://localhost/orders/addOrder",
				response.getHeader(HttpHeaders.LOCATION));
		
	}

	@Test
	public final void testChangeOrderBookStatus() throws Exception {
		Mockito.when(
				orderService.getAllOrderBook()).thenReturn(mockOrderBook);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/orders/changeOrderBookStatus").accept(
				MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		System.out.println(result.getResponse());
		String expected = "{id:Course1,name:Spring,description:10 Steps}";
		JSONAssert.assertEquals(expected, result.getResponse()
				.getContentAsString(), false);
	}
	@Test
	public final void testCreateNewOrderBook() throws Exception {
		Mockito.when(
				orderService.getAllOrderBook()).thenReturn(mockOrderBook);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/orders/createOrderBook").accept(
				MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		System.out.println(result.getResponse());
		String expected = "{id:Course1,name:Spring,description:10 Steps}";
		JSONAssert.assertEquals(expected, result.getResponse()
				.getContentAsString(), false);
	}

}
